<?php

if (!defined('BASEPATH'))
    exit('Não é permitido o acesso direto ao script.');

class Midia extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('website', 'conteudo', 'menu', 'banners', 'midias'));
    }

    /**
     * Este método mostra uma página com a listagem de todas as galerias
     * de mídia disponíveis no site.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return void 
     */
    public function index() {
        $interno = array();
        $interno['conteudo'] = $this->load->view('midia', null, true);
        $this->load->view('principal', $interno);
    }
    
    public function fotos(){
        $interno = array();
        $interno['conteudo'] = $this->load->view('fotos', null, true);
        $this->load->view('principal', $interno);
    }
    
    public function videos(){
         $interno = array();
        $interno['conteudo'] = $this->load->view('videos', null, true);
        $this->load->view('principal', $interno);
    }
    
    public function audios(){
        //TODO Criar a lista de galerias de áudio
    }
    
    public function arquivos(){
        //TODO Criar a lista de galerias de arquivos
    }

    public function ver($link) {
        $principal = array();
        $interno = array();
        $interno['link'] = $link;
        $principal['conteudo'] = $this->load->view('ver_midia', $interno, true);
        $this->load->view('principal', $principal);
    }

}

/* Sem fechamento para evitar erros de cabecalho. */