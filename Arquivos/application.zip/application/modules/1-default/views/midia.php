<h1>Lista de mídia</h1>
<?php $arrMidias = getListaMidia('Imagem'); ?>
<ul>
    <?php
    foreach ($arrMidias as $midia) {
        ?>
        <li>
            <p><?= $midia['titulo']; ?></p>
            <a href="<?= site_url('default/midia/ver/' . $midia['link']); ?>" rel="prettyPhoto" title="<?= $midia['titulo']; ?>">
                <span class="overlay zoom"></span>
                <img src="<?= base_url('midia/capas') . '/' . $midia['capa']; ?>" alt="" />
            </a>
        </li>
    <?php } ?>
</ul>