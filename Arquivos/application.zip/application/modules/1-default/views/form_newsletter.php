<h1>Newsletter</h1>
<p>Cadastre-se e receba nossas novidades em primeira mão.</p>
<?php if (isset($mensagem)): ?>
    <h2><?= $mensagem; ?></h2>
<?php else: ?>
    <form method="post" action="<?= site_url('default/newsletter') ?>">
        <fieldset>
            <p>Nome</p>
            <p><input type="text" name="nome" /></p>
            <?php echo form_error('nome', '<p class="error">', '</p>'); ?>
            <p>Email</p>
            <p><input type="text" name="email" /></p>
            <?php echo form_error('email', '<p class="error">', '</p>'); ?>
            <p><input type="submit" value="Cadastrar" /></p>
        </fieldset>
    </form>
<?php endif; ?>