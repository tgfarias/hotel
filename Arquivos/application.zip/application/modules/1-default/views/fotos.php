<section class="slides fotos">
    <div class="title">
        <h2 class="lastnotice-title">Fotos</h2>
        <span class="ico-camera"></span>
    </div>
    <?php $arrMidias = getListaMidia('Imagem'); ?>
    <nav class="grid-albuns">
        <ul>
            <?php foreach ($arrMidias as $midia) { ?>
                <li>
                    <a href="<?= site_url('galeria/' . $midia['link']); ?>" class="border3">
                        <span><img src="<?= base_url('application/modules/default/views'); ?>/images/ico-link.png" alt=""> <?= $midia['titulo']; ?></span>
                        <img src="<?= base_url('midia/capas') . '/' . $midia['capa']; ?>" alt="" class="capa">
                    </a>
                </li>
            <?php } ?>
        </ul>
    </nav>

    <!--    <nav class="pagination-albuns">
            <a href="#prev" class="prev-albuns border50">&laquo</a>
            <ul>
                <li><a href="#" class="border50 active-page">1</a></li>
                <li><a href="#" class="border50">2</a></li>
                <li><a href="#" class="border50">3</a></li>
                <li><a href="#" class="border50">4</a></li>
                <li><a href="#" class="border50">5</a></li>
                <li><a href="#" class="border50">6</a></li>
                <li><a href="#" class="border50">7</a></li>
            </ul>
            <a href="#next" class="next-albuns border50">&raquo</a>
        </nav>-->

    <div class="clear"></div>

</section><!-- fim slides -->

<section class="col-one">
    <article class="box-left">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Noticias</h2>
        </div>
        <?php $listaArtigos = getListaConteudo('Artigo', 2, 0, 3); ?>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid">
                <!-- ultimas noticias -->
                <ul>
                    <!-- loop de 3 noticias -->
                    <?php foreach ($listaArtigos as $art) { ?>
                        <li>
                            <div class="last-thumb">
                                <div class="bg-thumb">
                                    <img src="<?= base_url('midia/capas') . '/' . $art['cnt_capa']; ?>" alt="texto aqui" title="texto aqui">
                                </div>
                                <span class="lastnotice-date"><?= date('d/m/Y', strtotime($art['cnt_data_cad'])); ?></span>
                            </div>
                            <a href="<?= site_url('noticia/' . $art['cnt_link']); ?>" class="target-notice">
                                <h3><?= $art['cnt_titulo']; ?></h3>
                                <p><?= character_limiter($art['cnt_resumo'], '200'); ?></p>
                            </a>
                        </li>
                    <?php } ?>
                    <!-- Fim do loop das 3 notícias -->
                </ul>
            </nav>
        </div><!-- fim ultimas noticias -->
    </article>
    <!-- fim box-left -->

    <article class="box-right">
        <div class="title">
            <h2 class="newsletter-title">Receber Novidades</h2>
        </div>
        <div class="newsletter">
            <form action="<?= site_url('default/newsletter') ?>" method="post">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="newsletter-nome" placeholder="Seu nome Aqui...">
                <label for="nome">Email:</label>
                <input type="text" name="email" class="newsletter-email" placeholder="Agora seu Email...">
                <input type="submit" class="newsletter-btenviar" value="Cadastrar">
            </form>
        </div>
    </article><!-- fim box right -->
</section>
<!-- fim section col-one -->