<section class="slides sobre">
    <nav class="nav-sobre">
        <ul>
            <li><a href="#quem-somos">Quem Somos <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-sobre-ok.png" alt=""> </a></li>
            <li><a href="#misso">Missão <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-sobre-smile.png" alt=""></a></li>
            <li><a href="#viso"> Visão <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-sobre-lampada.png" alt=""></a></li>
        </ul>
    </nav>

    <article class="desc-sobre">
        <!-- rogerio de freitas -->
        <div class="empurra-desc-sobre rogerio" id="quem-somos">
            <?php $rogerio = getConteudoByLink('Quem-Somos'); ?>
            <h1><?= $rogerio['cnt_titulo']; ?></h1>
            <?= $rogerio['cnt_conteudo']; ?>
        </div>

        <!-- com a população -->
        <div class="empurra-desc-sobre populacao" id="misso">
            <?php $populacao = getConteudoByLink('Misso'); ?>
            <h1><?= $populacao['cnt_titulo']; ?></h1>
            <?= $populacao['cnt_conteudo']; ?>
        </div>

        <!-- na camara -->
        <div class="nacamara" id="viso">
            <?php $nacamara = getConteudoByLink('Viso'); ?>
            <h1><?= $nacamara['cnt_titulo']; ?></h1>
            <?= $nacamara['cnt_conteudo']; ?>
        </div>
    </article>
    <div class="clear"></div>
</section>
<!-- fim slides -->

<section class="col-one">
    <article class="box-left">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Noticias</h2>
        </div>
        <?php $listaArtigos = getListaConteudo('Artigo', 2, 0, 3); ?>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid">
                <!-- ultimas noticias -->
                <ul>
                    <!-- loop de 3 noticias -->
                    <?php foreach ($listaArtigos as $art) { ?>
                        <li>
                            <div class="last-thumb">
                                <div class="bg-thumb">
                                    <img src="<?= base_url('midia/capas') . '/' . $art['cnt_capa']; ?>" alt="texto aqui" title="texto aqui">
                                </div>
                                <span class="lastnotice-date"><?= date('d/m/Y', strtotime($art['cnt_data_cad'])); ?></span>
                            </div>
                            <a href="<?= site_url('noticia/' . $art['cnt_link']); ?>" class="target-notice">
                                <h3><?= $art['cnt_titulo']; ?></h3>
                                <p><?= character_limiter($art['cnt_resumo'], '200'); ?></p>
                            </a>
                        </li>
                    <?php } ?>
                    <!-- Fim do loop das 3 notícias -->
                </ul>
            </nav>
        </div><!-- fim ultimas noticias -->
    </article>
    <!-- fim box-left -->

    <article class="box-right">
        <div class="title">
            <h2 class="newsletter-title">Receber Novidades</h2>
        </div>
        <div class="newsletter">
            <form action="<?= site_url('default/newsletter') ?>" method="post">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="newsletter-nome" placeholder="Seu nome Aqui...">
                <label for="nome">Email:</label>
                <input type="text" name="email" class="newsletter-email" placeholder="Agora seu Email...">
                <input type="submit" class="newsletter-btenviar" value="Cadastrar">
            </form>
        </div>
    </article><!-- fim box right -->
</section>	<!-- fim section col-one -->
