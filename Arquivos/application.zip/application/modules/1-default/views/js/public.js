$(document).ready(function(){
	
	/**
	* Loading do site
	*/
	$('#all').loading({
		image: '.loading',
	});

	/**
	* Anima o formulario de sugestao do link da navegacao
	*/
	var formSugestao = $('.bg-form-sugestao'),
	formSendSugestao = $('.form-send form');
	formSendSugestao.hide();

	if(!formSugestao.is(':animated')){
		$('.enviesugestao').click(function(e){
			formSugestao.slideDown('slow',function(){
				formSendSugestao.fadeIn('slow');
			});
		});

		formSugestao.hover(function(){
			return;
		},function(){
			var tmr = setTimeout(function(){
				formSugestao.slideUp('slow');
			},1000);
		})
	}

	/**
	* Slide pagina principal
	*/
	$('.carousel-primary').carousel({
		next: '#next',
		prev: '#prev',
		auto: true,
		pagination: true,
		displayNumber: true,
	});

	/**
	* Carousel dos albuns de fotos
	* timer de 7s para passagens de lis
	*/
	$('.carousel-second').carousel({
		next:'#next-second',
		prev:'#prev-second',
		auto: true,
		timer: 7000,
	});

	/**
	* Carousel de visuzalicao de fotos e videos
	*/
	$('.pagination-view').carousel({
		prev: '.prev-carousel-view',
		next: '.next-carousel-view',
	});
	
	/**
	* Click na foto do carousel view, adiconar no big-photo o src da imagem
	*/
	$('.anima-carousel li a').each(function(index,elem){
		$(elem).click(function(event){
			event.preventDefault();
			var src_img = $(this).children('img').attr('src'),
			bigFoto = $('.big-photo').find('img');

			imgs = [];
			imgs[0] = $('.view-photo');
			imgs[1] = $('.view-photo2');

			pos_fundo = 0;
			pos_fundo++;
			(pos_fundo > imgs.length -1) ? pos_fundo = 0 :'';

				//imgs[pos_fundo].attr('src',src_img).hide().fadeIn('slow');
				bigFoto.attr('src',src_img).hide().fadeIn('slow');
			});
	});
	

	/**
	* script usado para criar tabs na pagina sobre
	*/
	$('.desc-sobre').hide().show('fade');
	$('.nav-sobre li a').each(function(index,elem){
		$(elem).live('click', function(event){
			event.preventDefault();
			var href = $(elem).attr('href');

			$('.desc-sobre').children('div').hide();
			$(href).show('slide','slow');
		});
	});

	/**
	* adicionar o link da pagina ao input da envio deo formulario
	* ao amigo na pagina de visualizacao de noticias
	*/
	var link_atual = window.location.href;
	$('.get_page').attr('value',link_atual);


	$('.pagination-view li a').each(function(index,elem){
		var src_iframe = $('.big-photo iframe');

		$(elem).click(function(e){
			e.preventDefault();

			var new_href = $(this).attr('href');
			log('OPa');
			src_iframe.fadeOut('slow');
			src_iframe.attr('src',new_href);
			src_iframe.fadeIn('slow');

		})
	});

}); //fim ready