<!--<div id="fb-root"></div>
<script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>-->
<?php $noticia = getConteudoByLink($linkNoticia); ?>
<section class="slides fotos noticias">
    <div class="title">
        <h2 class="lastnotice-title">Notícias</h2>
        <span class="ico-noticias"></span>
    </div>
    
    <article class="last-notice">
        <div class="box-left">
            <?php if($noticia['cnt_capa']){ ?>
            <div class="thumb-noticia">
                <img src="<?= base_url('midia/capas') . '/' . $noticia['cnt_capa']; ?>" alt="">
                <span><img src="<?= base_url('application/modules/default/views'); ?>/images/ico-camera-legenda.png" alt=""> <?= $noticia['cnt_titulo']; ?></span>
            </div>
            <?php } ?>
            <div class="shared-friend">
                <div class="title">
                    <h2 class="lastnotice-title">Envie para um amigo</h2>
                    <span class="ico-noticias2"></span>
                </div>
                <form action="<?= site_url('default/contato/indicacao'); ?>" method="post">
                    <input type="hidden" name="link" value="default/conteudo/ver/<?= $noticia['cnt_link']; ?>" />
                    <label for="">Nome:</label>
                    <input type="text" name="nome" class="border5" />

                    <label for="">Seu Email:</label>
                    <input type="text" name="email" class="border5" />
                        
                    <label for="">Nome do Amigo:</label>
                    <input type="text" name="nomeAmigo" class="border5" />

                    <label for="">Email do Amigo:</label>
                    <input type="text" name="emailAmigo" class="border5" />
                    
                    <!--label for="">Link: <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-link.png" alt=""></label>
                    <input type="text" value="" class="get_page border5"-->

                    <input type="submit" class="send-friend border5" value="Enviar" />
                </form>
            </div>
        </div>
        
        <div class="box-right">
            <div class="date">
                <span>Postado em: <?= date('d/m/Y', strtotime($noticia['cnt_data_cad'])); ?> <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-calendar.png" alt=""></span>
            </div>
            
            <nav class="social-notice">
                <ul>
                    <li>Compartilhe:</li>
                    <li><a href="facebook.com" class="ico-facebook-notice hidden">facebook</a></li>
                    <li><a href="twitter.com" class="ico-twitter-notice hidden">twitter</a></li>
                </ul>
            </nav>
            
            <div class="clear"></div>
            
            <!-- <a href="view-noticia.html" class="desc-noticia"> -->
                <div class="title-noticia">
                    <h1><?= $noticia['cnt_titulo']; ?></h1>
                </div>
                <div class="resumos-noticia">
                    <?= $noticia['cnt_conteudo']; ?>
                </div>
            <!-- </a> -->
        </div>
    </article>
    
    <div class="clear"></div>

</section><!-- fim slides -->

<section class="col-one all-notices comments">
    <article class="box-left box-all view-comments">
        <div class="title">
            <h2 class="lastnotice-title">Comentários facebook</h2>
            <span class="ico-comments"></span>
        </div>

        <div class="box-comments">
            <!-- Comentarios do facebook -->
            <div class="fb-comments" data-href="<?= site_url('noticia/'.$noticia['cnt_link']); ?>" data-num-posts="15" data-width="950"></div>
        </div>
        
    </article><!-- fim box-left -->
</section>  <!-- fim section col-one -->

<section class="col-one all-notices">
    <article class="box-left box-all view-box-all">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Noticias</h2>
        </div>
        <?php $listaArtigos = getListaConteudo('Artigo', 2, 0, 4); ?>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid box-grid-six"><!-- ultimas noticias -->
                <ul>
                    <!-- loop de 3 noticias -->
                    <?php foreach($listaArtigos as $art){ ?>
                    <li>
                        <div class="last-thumb">
                            <div class="bg-thumb">
                                <img src="<?= base_url('midia/capas') . '/' . $art['cnt_capa']; ?>" alt="<?= $art['cnt_titulo']; ?>" title="<?= $art['cnt_titulo']; ?>">
                            </div>
                            <span class="lastnotice-date"><?= date('d/m/Y', strtotime($art['cnt_data_cad'])); ?></span>
                        </div>
                        <a href="<?= site_url('noticia/'.$art['cnt_link']); ?>" class="target-notice">
                            <h3><?= $art['cnt_titulo']; ?></h3>
                            <p><?= character_limiter($art['cnt_resumo'],'200'); ?></p>
                        </a>
                    </li>
                    <?php } ?>
                </ul>
            </nav>                  
        </div><!-- fim ultimas noticias -->
    </article><!-- fim box-left -->
</section>  
<!-- fim section col-one -->