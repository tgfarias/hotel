<?php $primeiraNoticia = getListaConteudo('Artigo', 2, 0, 2); ?>
<section class="slides fotos noticias">
    <div class="title">
        <h2 class="lastnotice-title">Notícias</h2>
        <span class="ico-noticias"></span>
    </div>
    <article class="last-notice">
        <div class="box-left">
            <div class="thumb-noticia">
                <img src="<?= base_url('midia/capas') . '/' . $primeiraNoticia[0]['cnt_capa']; ?>" alt="">
                <span><img src="<?= base_url('application/modules/default/views'); ?>/images/ico-camera-legenda.png" alt=""> <?= $primeiraNoticia[0]['cnt_titulo']; ?></span>
            </div>
        </div>
        <div class="box-right">
            <div class="date">
                <span>Postado em: <?= date('d/m/Y', strtotime($primeiraNoticia[0]['cnt_data_cad'])); ?> <img src="<?= base_url('application/modules/default/views'); ?>/images/ico-calendar.png" alt=""></span>
            </div>
            <nav class="social-notice">
                <ul>
                    <li>Compartilhe:</li>
                    <li><a href="facebook.com" class="ico-facebook-notice hidden">facebook</a></li>
                    <li><a href="twitter.com" class="ico-twitter-notice hidden">twitter</a></li>
                </ul>
            </nav>
            <div class="clear"></div>
            <a href="<?= site_url('noticia/'.$primeiraNoticia[0]['cnt_link']); ?>" class="desc-noticia">
                <div class="title-noticia">
                    <h1><?= $primeiraNoticia[0]['cnt_titulo']; ?></h1>
                </div>
                <div class="resumos-noticia">
                    <p><?= character_limiter($primeiraNoticia[0]['cnt_conteudo'], 700); ?></p>
                </div>
                <?= anchor('noticia/'.$primeiraNoticia[0]['cnt_link'], 'Leia Mais...', array('class'=>'ancora-noticia')); ?>
            </a>
        </div>
    </article>
    <div class="clear"></div>
</section><!-- fim slides -->

<section class="col-one all-notices">
    <article class="box-left box-all">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Noticias</h2>
        </div>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid box-grid-six">
                <!-- ultimas noticias -->
                <ul>
                    <?php foreach ($lista as $cont): ?>
                    <li>
                        <div class="last-thumb">
                            <div class="bg-thumb">
                                <img src="<?= base_url('midia/capas') . '/' . $cont->cnt_capa; ?>" alt="<?= $cont->cnt_titulo; ?>" title="<?= $cont->cnt_titulo; ?>">
                            </div>
                            <span class="lastnotice-date"><?= date('d/m/Y', strtotime($cont->cnt_data_cad)); ?></span>
                        </div>
                        <a href="<?= site_url('noticia/'.$cont->cnt_link); ?>" class="target-notice">
                            <h3><?= $cont->cnt_titulo; ?></h3>
                            <p><?= $cont->cnt_resumo; ?></p>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
<!--            <nav class="pagination-albuns pagination-noticias">
                <a href="#prev" class="prev-albuns border50">&laquo</a>
                <ul>
                    <li><a href="#" class="border50 active-page">1</a></li>
                    <li><a href="#" class="border50">2</a></li>
                    <li><a href="#" class="border50">3</a></li>
                    <li><a href="#" class="border50">4</a></li>
                    <li><a href="#" class="border50">5</a></li>
                    <li><a href="#" class="border50">6</a></li>
                    <li><a href="#" class="border50">7</a></li>
                </ul>
                <a href="#next" class="next-albuns border50">&raquo</a>
            </nav>-->
        </div><!-- fim ultimas noticias -->
    </article><!-- fim box-left -->
</section>	<!-- fim section col-one -->