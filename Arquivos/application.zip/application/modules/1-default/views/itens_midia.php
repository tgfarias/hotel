<?php
$arrMidias = getMidiaByLink($link);
$galeria = $arrMidias['galeria'];
$arrItens = $arrMidias['itens'];
?>
<h1>Itens da galeria de mídia</h1>
<p><?= $galeria['titulo']; ?></p>
<ul>
<?php foreach ($arrItens as $itens) { ?>
        <li>
            <p>
    <?php
    switch ($itens['tipo']):
        case 'Youtube':
            ?>
                    <p><?= $itens['titulo']; ?></p>
                        <?= $itens['conteudo']; ?>
                        <?php
                        break;
                    case 'Audio':
                        ?>
                    <a href="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" >
                    <?= $itens['titulo']; ?>
                    </a>
                        <?php
                        break;
                    case 'Arquivo':
                        ?>
                    <a href="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" >
                    <?= $itens['titulo']; ?>
                    </a>
                        <?php
                        break;
                    case 'Imagem':
                        ?>
                    <a href="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" >
                        <img src="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" />
                    </a>
            <?php
            break;
        case 'Massa':
            ?>
                    <a href="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" >
                        <img src="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" />
                    </a>
            <?php
            break;
    endswitch;
    ?>
            </p>
        </li>
        <?php } ?>
</ul>