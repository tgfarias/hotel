<!-- Início slides -->
<section class="slides">
    <nav class="carousel-primary">
        <a href="#prev" class="carousel-ui hidden" id="prev">prev</a>
        <ul class="anima-carousel">
            <?php $banners = getBanners('slide'); ?>
            <?php foreach ($banners as $ban) { ?>
                <li>
                    <a href="<?= $ban['banner']['link']; ?>" class="legendas">
                        <h3><?= $ban['banner']['titulo']; ?></h3>
                        <p><?= $ban['banner']['html']; ?></p>
                    </a>
                    <!-- imagem 1 -->
                    <img src="<?= base_url('midia/banners') . '/' . $ban['banner']['arquivo']; ?>" alt="Texto de Alt" title="Texto de Titulo">
                </li>
            <?php } ?>
        </ul>
        <a href="#next" class="carousel-ui hidden" id="next">next</a>
    </nav>
    <span class="sombra-slide"><img src="<?= base_url('application/modules/default/views'); ?>/images/sombra-slide.png" alt=""></span>
</section>
<!-- fim slides -->

<section class="col-one">
    <article class="box-left">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Notícias</h2>
        </div>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid">
                <!-- ultimas noticias -->
                <?php $listaArtigos = getListaConteudo('Artigo', 2, 0, 3); ?>
                <ul>
                    <!-- loop de 3 noticias -->
                    <?php foreach ($listaArtigos as $art) { ?>
                        <li>
                            <div class="last-thumb">
                                <div class="bg-thumb">
                                    <img src="<?= base_url('midia/capas') . '/' . $art['cnt_capa']; ?>" alt="texto aqui" title="texto aqui">
                                </div>
                                <span class="lastnotice-date"><?= date('d/m/Y', strtotime($art['cnt_data_cad'])); ?></span>
                            </div>
                            <a href="<?= site_url('noticia/' . $art['cnt_link']); ?>" class="target-notice">
                                <h3><?= $art['cnt_titulo']; ?></h3>
                                <p><?= character_limiter($art['cnt_resumo'], '200'); ?></p>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </nav>
        </div><!-- fim ultimas noticias -->
    </article><!-- fim box-left -->

    <article class="box-right">
        <div class="title">
            <h2 class="newsletter-title">Receber Novidades</h2>
        </div>
        <div class="newsletter">
            <form action="<?= site_url('default/newsletter') ?>" method="post">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="newsletter-nome" placeholder="Seu nome Aqui...">
                <label for="nome">Email:</label>
                <input type="text" name="email" class="newsletter-email" placeholder="Agora seu Email...">
                <input type="submit" class="newsletter-btenviar" value="Cadastrar">
            </form>
        </div>
    </article><!-- fim box right -->
</section>
<!-- fim section col-one -->

<section class="col-two">
    <?php $arrMidias = getUltimasMidias('Video', 0, 1); ?>
    <article class="box-videos">
        <div class="title">
            <h2 class="videos-title">Videos</h2>
        </div>
        <div class="videos">
            <!-- Tamanho do video 348 x 213 -->
            <iframe width="348" height="250" src="http://www.youtube.com/embed/<?= $arrMidias[0]['conteudo']; ?>" frameborder="0" allowfullscreen></iframe>
        </div>
        <div class="desc-videos">
            <p><?= $arrMidias[0]['descricao']; ?></p>
        </div>
    </article>
    <!-- box videos -->

    <article class="box-twitter">
        <div class="title">
            <h2 class="videos-title">Ultimos Requerimentos</h2>
        </div>

        <article class="list-proposta last-prop">
            <nav>
                <ul>
                    <!-- laço de 5 itens feito por <li> -->
                    <?php /*foreach($ultimas_propostas->result() as $row){
						$data = explode('-', $row->data);
	                	$mes = array('01'=>'Jan', '02'=>'Fev', '03'=>'Mar', '04'=>'Abr', '05'=>'Mai', '06'=>'Jun', '07'=>'Jul', '08'=>'Ago', '09'=>'Set', '10'=>'Out', '11'=>'Nov', '12'=>'Dez' );
	                	?>
	                <li>
	                    <div class="data-upload">
	                        <p class="mes"><?= $mes[$data[1]]; ?></p>
	                        <p class="ano"><?= $data[0]; ?></p>
	                    </div>
	                    <div class="title-proposta">
	                        <h1><a href="<?= base_url('midia/propostas').'/'.$row->arquivo; ?>" target="_blank">
	                        	<?= $row->titulo; ?></a>
	                        </h1>
	                    </div>
	                </li>
	                <?php }*/ ?>
                    <!-- <li>
                        <div class="data-upload">
                            <p class="mes">Jan</p>
                            <p class="ano">2013</p>
                        </div>
                        <div class="title-proposta">
                            <h1>Continually enable equity invested communities vis-a-vis resource maximizing imperatives. Enthusiastically network plug-and-play e-markets rather than leveraged collaboration and idea-sharing. Conveniently negotiate adaptive synergy via client-centered applications. Intrinsicly transform </h1>
                        </div>
                    </li> -->
                    
                </ul>
            </nav>
        </article>
        
    </article>
    <!-- box-twitter -->

    <article class="box-facebook">
        <div class="fb-like-box" data-href="http://www.facebook.com/pages/Life-Sites/175976219141126" data-width="260" data-height="290" data-show-faces="true" data-stream="false" data-border-color="white" data-header="true"></div>
    </article>
    <!-- box-facebook -->
    
</section>
<!-- fim section col-two -->

<section class="col-three">
    <div class="title">
        <h2 class="lastfotos-title">Ultimas fotos</h2>
    </div>

    <article class="box-lastfotos">
        <?php $listaFotos = getUltimasMidias('Imagem', 0, 10); ?>
        <nav class="carousel-second">
            <a href="#prev" class="carousel-ui-second hidden border5" id="prev-second">prev-second</a>
            <ul>
                <?php foreach($listaFotos as $foto){ ?>
                <li>
                    <a class="transition3"><img src="<?= base_url('midia/galerias/'.$foto['pasta']) . '/' . $foto['arquivo']; ?>" width="200" height="170" alt=""></a>
                </li>
                <?php } ?>
            </ul>
            <a href="#next" class="carousel-ui-second hidden border5" id="next-second">next-second</a>
        </nav>
    </article>
    <?= anchor('fotos', 'Confira o album completo', array('class'=>'all-albuns border5')); ?>
</section>
<!-- Fim col-three -->