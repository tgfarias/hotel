<!doctype html>
<html lang="pt-BR">
<head>
    <!-- Metas -->
    <meta charset="UTF-8">
    <meta name="application-name" content="Rogerio Freitas Vereador de Palmas">
    <meta name="author" content="Life Sites Desenvolvimento Web">
    <meta name="copyright" content="(c) Life Sites Desenvolvimento Web">
    <meta name="description" content="Site do Vereador Rogerio Freitas">
    <meta name="keywords" content="vereador, palmas , rogerio freitas , freitas , policita, site de vereador, site do rogerio de freitas , site de vereador de palmas">
    <meta name="robots" content="index/follow">
    <meta name="googlebot" content="index/follow">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="MobileOptimized" content="320"/>
    <meta http-equiv="X-UA-Compatible" content="Ie=edge,chrome=1" /> 
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />

    <!-- favicon -->
    <link rel="apple-touch-icon" href="<?= base_url('application/modules/default/views'); ?>/favicon.png" /><!-- autoriza criação de icone para iphones no dashboard -->
    <link rel="shortcut icon" href="<?= base_url('application/modules/default/views'); ?>/favicon.ico" /><!-- favicon-->

    <!-- CSS -->
    <link rel="stylesheet" href="<?= base_url('application/modules/default/views'); ?>/css/public.css">
    <link rel="stylesheet" href="<?= base_url('application/modules/default/views'); ?>/css/ui-lightness/jquery-ui-1.9.0.custom.min.css">

    <!-- JS -->
    <script src="<?= base_url('application/modules/default/views'); ?>/js/lib/jquery-1.8.2.js"></script>
    <script src="<?= base_url('application/modules/default/views'); ?>/js/lib/all.custom.plugins.js"></script>
    <script src="<?= base_url('application/modules/default/views'); ?>/js/lib/css.selector.custom.js"></script>
    <script src="<?= base_url('application/modules/default/views'); ?>/js/public.js"></script>

    <!-- socials APIs -->
    <script src="http://connect.facebook.net/pt_BR/all.js#xfbml=1" charset="utf-8"></script>

    <!-- Title -->
    <title><?= get_conf('titulo_site'); ?></title>
</head>
<body>
    <div class="loading border5"><p>carregando..</p></div>
    
    <header class="topo">              
     <div class="center">

      <?= anchor('', '<h1 class="">LOGO CLIENTE</h1>',array('class'=>'logo')); ?>

      <nav class="socials-topo">

        <h3>Siga-nos nas redes sociais</h3>

        <ul>
            <li><a href="#" class="twitter hidden transition3">twitter</a></li>
            <li><a href="#" class="facebook hidden transition3">facebook</a></li>
            <li><a href="#" class="skype hidden transition3">skype</a></li>
            <li><a href="#" class="rss hidden transition3">rss</a></li>
        </ul>

    </nav>

    <div class="tel right clear">
        <p>Entre em Contato</p>
        <h1>+55 63 3215-5555</h1>
    </div>

    <div class="tel address right clear">
        <p>Endereço</p>
        <h1>912 Sul Al  06 Lote 05
            Palmas - TO</h1>
    </div>
</div>
</header>

<nav class="main-nav">
    <div class="center">
        <ul>
            <li><?= anchor('', 'Home'); ?></li>
            <li><?= anchor('sobre', 'Sobre', array('class' => 'transition3')); ?></li>
            <li>
                <a class="transition3">Galeria</a>
                <!-- Dropdown da galeria de fotos e videos -->
                <ul class="menu-dropdown">
                    <li><?= anchor('fotos', 'Album de Fotos'); ?></li>
                    <li><?= anchor('videos', 'Album de Videos'); ?></li>
                </ul>
            </li>
            <li><?= anchor('noticias', 'Notícias', array('class' => 'transition3')) ?></li>
            <li><?= anchor('contato', 'Fale Conosco', array('class' => 'transition3')) ?></li>
        </ul>
    </div>
</nav>
<span class="fita-amarela"></span>

<div id="all">  
    <div class="breadcumb">
        <p class="link-bread">
            Você está em
            <?php
            
            //echo '<p>'.uri_string().'</p>';
            echo anchor('', 'Home ');

            $caminho = uri_string();
            switch ($caminho) {
                case 'default/conteudo/sobre':
                echo anchor('default/conteudo/sobre', '/ Sobre ');
                break;
                case 'default/midia/fotos':
                echo anchor('default/midia/fotos', '/ Galeria / Fotos ');
                break;
                case 'default/midia/videos':
                echo anchor('default/midia/videos', '/ Galeria / Vídeos ');
                break;
                case 'default/conteudo/artigos/2':
                echo anchor('default/conteudo/artigos/2', '/ Notícias ');
                break;
                case 'default/conteudo/propostas/3':
                echo anchor('default/conteudo/artigos/2', '/ Propostas / Requerimentos ');
                break;
                case 'default/conteudo/propostas/4':
                echo anchor('default/conteudo/artigos/2', '/ Propostas / Leis ');
                break;
                case 'default/conteudo/propostas/5':
                echo anchor('default/conteudo/artigos/2', '/ Propostas / Projetos de lei ');
                break;
                case 'default/contato':
                echo anchor('default/contato', '/ Contato ');
                break;
            }

            ?>
        </p>
    </div>

    <?= $conteudo; ?>

</div><!-- fim all -->

<footer>
    <div class="center">
        <div class="infos-footer">
            <h4>Informações de Contato</h4>
            <nav>
                <ul>
                    <li class="ico-phone">+55 63 3215-5555</li>
                    <li class="ico-mail">contato@rogeriofreitas.com.br</li>
                    <li class="ico-adress">912 Sul Alameda 10 Lote 10 - Palmas / TO</li>
                </ul>
            </nav>
        </div>

        <div class="intranet-footer">
            <h4>Acesso a Intranet</h4>
            <form action="" method="" class="">
                <input type="text" placeholder="User / Email" class="border5">
                <input type="password" placeholder="Senha" class="border5">
                <input type="submit" class="btenviar-intranet border5" value="Login">
            </form>
        </div>
    </footer>

    <div class="rodape">
        <div class="center">
            <nav>
                <ul>
                    <li><?= anchor('default/conteudo/ver/Imprensa', 'Imprensa'); ?></li>
                    <li><?= anchor('default/conteudo/ver/Privacidade', 'Privacidade'); ?></li>
                    <li><?= anchor('default/conteudo/artigos/2', 'Notícias'); ?></li>
                            <!-- <li><a href="#">Mapa do Site</a></li>
                            <li><a href="#">Ajuda</a></li> -->
                        </ul>
                    </nav>

                    <p class="assinatura">
                        <span>Desenvolvido por</span> 
                        <a href="http://lifesites.com.br" target="_blank">Life Sites</a>
                    </p>
                </div>
            </div>

        </div>
    </body>
    </html>