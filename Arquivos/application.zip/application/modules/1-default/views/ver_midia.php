<?php

$arrMidias = getMidiaByLink($link);
$galeria = $arrMidias['galeria'];
$arrItens = $arrMidias['itens'];

?>
<section class="slides fotos view">
    <div class="title">
        <h2 class="lastnotice-title"><?= $galeria['titulo']; ?></h2>
        <span class="ico-camera"></span>
    </div>

    <div class="bg-big-photo">
        <div class="big-photo border3">
            <?php if($galeria['tipo'] == 'Youtube'){ ?>
            <iframe width="640" height="345" src="http://www.youtube.com/embed/<?= $arrMidias['itens'][0]['conteudo']; ?>" frameborder="0" allowfullscreen></iframe>
            <?php } else { ?>
            <img src="<?= base_url('midia/capas') . '/' . $galeria['capa']; ?>" alt="" class="view-photo">
            <?php } ?>
        </div>
    </div>

    <div class="pagination-view">
        <a href="#prev" class="prev-carousel-view hidden">&laquo</a>
        <nav class="anima-carousel">
            <ul>
                <?php foreach ($arrItens as $itens) { 
                    if($galeria['tipo'] == 'Youtube'){
                    ?>
                    <li><a href="http://www.youtube.com/embed/<?= $itens['conteudo']; ?>" class=""><img src="http://img.youtube.com/vi/<?= $itens['conteudo']; ?>/2.jpg" alt=""></a></li>
                <?php } else { ?>
                    <li><a href="#" class=""><img src="<?= base_url('midia/galerias') . '/' . $itens['pasta'] . '/' . $itens['arquivo']; ?>" alt=""></a></li>
                <?php } } ?>
            </ul>
        </nav>
        <a href="#prev" class="next-carousel-view hidden">&raquo</a>
    </div>
</section><!-- fim slides -->

<section class="col-one">
    <article class="box-left">
        <div class="title">
            <h2 class="lastnotice-title">Ultimas Noticias</h2>
        </div>
        <?php $listaArtigos = getListaConteudo('Artigo', 2, 0, 3); ?>
        <div class="lastnotice-list">
            <nav class="lastnotice-grid">
                <!-- ultimas noticias -->
                <ul>
                    <!-- loop de 3 noticias -->
                    <?php foreach ($listaArtigos as $art) { ?>
                        <li>
                            <div class="last-thumb">
                                <div class="bg-thumb">
                                    <img src="<?= base_url('midia/capas') . '/' . $art['cnt_capa']; ?>" alt="texto aqui" title="texto aqui">
                                </div>
                                <span class="lastnotice-date"><?= date('d/m/Y', strtotime($art['cnt_data_cad'])); ?></span>
                            </div>
                            <a href="<?= site_url('noticia/' . $art['cnt_link']); ?>" class="target-notice">
                                <h3><?= $art['cnt_titulo']; ?></h3>
                                <p><?= character_limiter($art['cnt_resumo'], '200'); ?></p>
                            </a>
                        </li>
                    <?php } ?>
                    <!-- Fim do loop das 3 notícias -->
                </ul>
            </nav>
        </div><!-- fim ultimas noticias -->
    </article>
    <!-- fim box-left -->

    <article class="box-right">
        <div class="title">
            <h2 class="newsletter-title">Receber Novidades</h2>
        </div>
        <div class="newsletter">
            <form action="<?= site_url('default/newsletter') ?>" method="post">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" class="newsletter-nome" placeholder="Seu nome Aqui...">
                <label for="nome">Email:</label>
                <input type="text" name="email" class="newsletter-email" placeholder="Agora seu Email...">
                <input type="submit" class="newsletter-btenviar" value="Cadastrar">
            </form>
        </div>
    </article><!-- fim box right -->
</section>