<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Este controller faz o funcionamento básico do fale conosco para ser
 * usado nos sites.
 *
 * @access public
 * @author Eliel de Paula <elieldepaula@gmail.com>
 * @since 0.0.1 21/01/2013
 * @access public
 */
class contato extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('conteudo', 'banners', 'veiculos', 'links'));
    }

    /**
     * Este método exibe a página de contato com o formulário de envio básico.
     * 
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @access public
     * @return void 
     */
    public function index() {
        
        $this->form_validation->set_rules('nome', 'Nome', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('assunto', 'Assunto', 'required');
        $this->form_validation->set_rules('mensagem', 'Mensagem', 'required');
        
        if ($this->form_validation->run() == FALSE):
            $interno = array();
            $interno['conteudo'] = $this->load->view('contato', NULL, TRUE);
            $this->load->view('principal', $interno);
        else:
            
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            //$telefone = $_POST['telefone'];
            $mensagem = $_POST['mensagem'];
            
            $msg = "";
            $msg .= "Mensagem enviada pelo site.\n\n";
            $msg .= "Nome: $nome\n";
            $msg .= "Email: $email\n";
            //$msg .= "Telefone: $telefone\n\n";
            $msg .= "Mensagem\n";
            $msg .= "------------------------------------------------------\n\n";
            $msg .= "$mensagem";
            $msg .= "\n\n";
            
            $this->load->library('email');
            $this->email->from($email, $nome);
            $this->email->to(get_conf('destino_contato'));
            $this->email->subject('[Fale Conosco]');
            $this->email->message($msg);	

            if($this->email->send()):
                echo '<script>alert("Sua mensagem foi enviada com sucesso!");</script>';
                redirect('default/contato', 'script');
            else:
                echo '<script>alert("Erro, sua mensagem não pode ser enviada, tente novamente mais tarde.");</script>';
                redirect('default/contato', 'script');
            endif;
        endif;
    }
    
    /**
     * Este método foi desenvolvido exclusivamente para o site do Vereador Rogério Freitas
     * para que um internauta pudesse enviar uma sugestão de ação para o vereador.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @since 0.1 07/02/2013
     * @return void
     */
    public function sugestao(){
        
        $this->form_validation->set_rules('nome', 'Nome', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('mensagem', 'Mensagem', 'required');
        
        if ($this->form_validation->run() == FALSE):
            redirect('default/home', 'script');
        else:
            
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $mensagem = $_POST['mensagem'];
            
            $msg = "";
            $msg .= "Sugestão enviada pelo site.\n\n";
            $msg .= "Nome: $nome\n";
            $msg .= "Email: $email\n";
            $msg .= "Mensagem\n";
            $msg .= "------------------------------------------------------\n\n";
            $msg .= "$mensagem";
            $msg .= "\n\n";
            
            $this->load->library('email');
            $this->email->from($email, $nome);
            $this->email->to(get_conf('destino_contato'));
            $this->email->subject('[Sugestões pelo site]');
            $this->email->message($msg);	

            if($this->email->send()):
                echo '<script>alert("Sua sugestão foi enviada com sucesso!");</script>';
                redirect('default/home', 'script');
            else:
                echo '<script>alert("Erro, sua sugestão não pode ser enviada, tente novamente mais tarde.");</script>';
                redirect('default/home', 'script');
            endif;
        endif;
    }
    
    /**
     * Este método foi desenvolvido exclusivamente para o site do Vereador Rogério Freitas
     * para que um internauta pudesse enviar uma indicação de um artigo para um amigo.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @since 0.1 07/02/2013
     * @return void
     */
    public function indicacao(){
        
        $this->form_validation->set_rules('nome', 'Nome', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('nomeAmigo', 'Nome do Amigo', 'required');
        $this->form_validation->set_rules('emailAmigo', 'Email do Amigo', 'required|valid_email');
        
        if ($this->form_validation->run() == FALSE):
            $link = $_POST['link'];
            redirect($link, 'script');
        else:
            
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $nomeAmigo = $_POST['nomeAmigo'];
            $emailAmigo = $_POST['emailAmigo'];
            $link = $_POST['link'];
            
            $msg = "";
            $msg .= "\nOlá $nomeAmigo! $nome te indicou um artigo do Vereador Rogerio Freitas\n";
            $msg .= "pois achou que seria do seu interesse.\n\n";
            $msg .= "Clique no link abaixo para visualizar o artigo na íntegra.\n\n";
            $msg .= "Link: " . site_url($link) . " \n\n";
            $msg .= "Acesse nosso site e assine nossa Newsletter para ficar por dentro das \n";
            $msg .= "ações do Vereador Rogério Freitas.\n\n";
            $msg .= "Até logo!\n\n";
            
            $this->load->library('email');
            $this->email->from($email, $nome);
            $this->email->to($emailAmigo);
            $this->email->subject('Sugestão de artigo do site do Vereador Rogerio Freitas.');
            $this->email->message($msg);
            
            //TODO Criar aqui o cadastro destes dados na base de Newsletter.

            if($this->email->send()):
                echo '<script>alert("Sua indicação foi enviada com sucesso!");</script>';
                redirect($link, 'script');
            else:
                echo '<script>alert("Erro, sua indicação não pode ser enviada, tente novamente mais tarde.");</script>';
                redirect($link, 'script');
            endif;
        endif;
    }
}