<?php

if (!defined('BASEPATH'))
    exit('Não é permitido o acesso direto ao script.');

class Produtos extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('website', 'conteudo', 'menu', 'banners', 'midias', 'veiculos', 'links'));
    }
    
    public function index(){
        $principal = array();
        $interno = array();
        $principal['conteudo'] = $this->load->view('lista_estoque',$interno,true);
        $this->load->view('principal',$principal);
    }

    public function busca(){
        
        $principal = array();
        $interno = array();
        
        $nome = @$_POST['veiculo'];
        $ano_fab = @$_POST['ano_fab'];
        $ano_mod = @$_POST['ano_mod'];
        $valor_min = @$_POST['valor_min'];
        $valor_max = @$_POST['valor_max'];
        $estado = @$_POST['cod_estado'];
        $cidade = @$_POST['cod_cidade'];
        
        $this->load->model('veiculos_model');
        
        $interno['resultado'] = $this->veiculos_model->busca_veiculo($nome, $ano_fab, $ano_mod, $valor_min, $valor_max, $estado, $cidade);
        $principal['conteudo'] = $this->load->view('lista_produto',$interno,true);
        $this->load->view('principal',$principal);
        
    }
    
    /**
     * Este método faz a exibição da visualização dos detalhes do produto.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return void 
     */
    public function ver($cod_produto) {
        $principal = array();
        $interno = array();
        $interno['cod_veiculo'] = $cod_produto;
        $principal['conteudo'] = $this->load->view('ver_produto', $interno, true);
        $this->load->view('principal', $principal);
    }

}

/* Sem fechamento para evitar erros de cabecalho. */