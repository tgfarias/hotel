<?php

if (!defined('BASEPATH'))
    exit('Não é permitido o acesso direto ao script.');

/**
 * Esta é a classe de controle dos cadastros de newsletter no site.
 * 
 * @package Esqueleto
 * @author Eliel de Paula <elieldepaula@gmail.com>
 * @since 0.1 23/01/2013
 * @access public
 */
class Newsletter extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('website', 'conteudo', 'menu', 'banners', 'veiculos', 'links'));
    }

    public function index() {
        // Regras de validação.
        $this->form_validation->set_rules('nome', 'Nome', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        // Valida os campos de acordo com as regras.
        if ($this->form_validation->run() == FALSE):
            $interno = array();
            $interno['conteudo'] = $this->load->view('form_newsletter', NULL, TRUE);
            $this->load->view('principal', $interno);
        else:
            $principal = array();
            $interno = array();
            $this->load->model('newsletters_model');
            $dados_save = array();
            $dados_save['new_nome'] = $_POST['nome'];
            $dados_save['new_email'] = $_POST['email'];
            $dados_save['new_ativo'] = 1;
            $dados_save['new_data_cad'] = date('Y-m-d H:i:s');
            // Cadastra os dados no banco de dados.
            if ($this->newsletters_model->save($dados_save)):
//                $interno['mensagem'] = "Seu email foi cadastrado com sucesso!";
//                $principal['conteudo'] = $this->load->view('form_newsletter', $interno, TRUE);
//                $this->load->view('principal', $principal);
                redirect('', 'script');
            else:
                $interno['mensagem'] = "Seu email não pode ser cadastrado, tente novamente mais tarde.";
                $principal['conteudo'] = $this->load->view('form_newsletter', $interno, TRUE);
                $this->load->view('principal', $principal);
            endif;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */
