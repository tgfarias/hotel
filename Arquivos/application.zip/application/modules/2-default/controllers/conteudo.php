<?php

if (!defined('BASEPATH')) exit ('Não é permitido o acesso direto ao script.');

/**
 * Esta classe faz o funcionamento do conteúdo no site. Ela contém todos os
 * métodos básicos para exibição de conteúdo ou listagem por categoria.
 * 
 * //TODO Criar a lisagem por seção.
 * 
 * @package Esqueleto
 * @author Eliel de Paula <elieldepaula@gmail.com>
 * @since 0.1 21/01/2013 
 * @access public
 */
class Conteudo extends MX_Controller {

    /**
     * Esta variável defini a categoria do conteúdo que deverá ser exibida
     * na listagem de conteúdo.
     * 
     * @var int Código da seção que será listada.
     */
    private $categoria = 2;

    function __construct() {
        parent::__construct();
        $this->load->helper(array('conteudo', 'banners', 'veiculos', 'links'));
    }

    /**
     * Este método mostra a página inicial do site.
     *
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @return void
     */
    public function index() {

        $this->load->model('conteudo_model');

        $principal = array();
        $interno = array();
        $config = array();

        // Paginação
        $limit = 2;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);

        $config['base_url'] = site_url('default/conteudo/index/pag');
        $config['total_rows'] = $this->conteudo_model->count_all($this->categoria);
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;

        $this->pagination->initialize($config);
        $interno['lista'] = $this->conteudo_model->get_paged_list($limit, $offset, $this->categoria)->result();
        $interno['paginacao'] = $this->pagination->create_links();
        $principal['conteudo'] = $this->load->view('lista_conteudo', $interno, TRUE);
        //$interno['noticias'] = getListaConteudo('Artigo', '3', 0, 10);
        $this->load->view('principal', $principal);
    }

    public function artigos($cod_categoria) {

        $this->load->model('conteudo_model');

        $principal = array();
        $interno = array();
        $config = array();

        // Paginação
        $limit = 25;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);

        $config['base_url'] = site_url('default/conteudo/index/pag');
        $config['total_rows'] = $this->conteudo_model->count_all($cod_categoria);
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;

        $this->pagination->initialize($config);
        $interno['lista'] = $this->conteudo_model->get_paged_list($limit, $offset, $cod_categoria)->result();
        $interno['paginacao'] = $this->pagination->create_links();
        $interno['cod_categoria'] = $cod_categoria;
        $principal['conteudo'] = $this->load->view('lista_conteudo', $interno, TRUE);

        $this->load->view('principal', $principal);
    }

    public function ver($link) {

        $principal = array();
        $interno = array();
        
        $interno['link'] = $link;
        $principal['conteudo'] = $this->load->view('ver_conteudo', $interno, TRUE);
        $this->load->view('principal', $principal);

    }

    public function propostas($categoria) {

        $this->load->model('categorias_model');
        $this->load->model('propostas_model');

        $principal = array();
        $interno = array();

        $queryCat = $this->categorias_model->get_by_id($categoria)->row();

        $interno['titulo'] = $queryCat->cat_titulo;
        $interno['lista'] = $this->propostas_model->list_all($categoria);
        $principal['conteudo'] = $this->load->view('propostas_base', $interno, TRUE);

        $this->load->view('principal', $principal);
        
    }

}

/* Sem fechamento para evitar erros de cabecalho. */
