<section class="ver-conteudo">

    <header>
        <h1>Envie seu Email</h1>
    </header>
    
    <div class="contato">
        <form action="<?= site_url('default/contato'); ?>" method="post" class="form-fale">
            <span class="danger-notice"> * Atenção todos os campos são obrigátorios.</span>
            
            <label for=""> 
                <p class="post">Nome:</p>
                <input type="text" name="nome" class="border5">
                <?php echo form_error('nome', '<p class="error">', '</p>'); ?>
            </label>
            
            <label for="">
                <p class="post">Email:</p>
                <input type="text" name="email" class="border5">
                <?php echo form_error('email', '<p class="error">', '</p>'); ?>
            </label>
                
            <label for="">
                <p class="post">Assunto:</p>
                <input type="text" name="assunto" class="border5">
                <?php echo form_error('assunto', '<p class="error">', '</p>'); ?>
            </label>
            
            <label for="">
                <p class="post">Mensagem:</p>
                <textarea cols="30" name="mensagem" rows="10" class="border5"></textarea> 
                <?php echo form_error('mensagem', '<p class="error">', '</p>'); ?>
            </label>

            <label for="">
                <p class="post"></p>
                <input type="submit" class="" value="Enviar">
            </label>
            
        </form>
    </div>
    
    <div class="clear"></div>
    
</section>