$(document).ready(function(){

	/** =====
	Loading geral das paginas
	========*/
	var openAll = $('.all').loading({
		image: '.loading',
	});

	
	/**  ===========
		Abre o submenu , primeiro faz a pesquisa dentro da li,
		se estiver visivel ele some,
		verificando se existe ul e se a ul tem uma class submenu,
		se existir , para o click e abre o submenu

		@author Thadeu Esteves
		@date 25/02/2013
	===============*/
	$('.nav-main li').each(function(index,elem){
		$(this).click(function(e){	
			var subMenu = $(this).find('ul.submenu'),
				ulParent  = $('.nav-main ul ul');

			if(!$(this).find('ul').hasClass('submenu')){
				return;
			}else{
				if(!subMenu.is(':visible')){
					ulParent.hide('fade');
					subMenu.show('fade');
				}else{
					subMenu.hide('fade');
				}
			}
		});		
	});

	$('.thumbs li img').click(function(evt){
		evt.preventDefault();

		var a = $(this).attr('src'),
			figureImg = $('.veiculo').find('figure img');

		figureImg.fadeOut();
		figureImg.attr('src',a);
		figureImg.fadeIn();
	})
})