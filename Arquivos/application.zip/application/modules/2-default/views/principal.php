<!doctype html>
<html lang="pt-BR">
<head>
    <!-- Metas -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- favicon -->
    <link rel="apple-touch-icon" href="<?= path_views(); ?> ?>/favicon.png" /><!-- autoriza criação de icone para iphones no dashboard -->
    <link rel="shortcut icon" href="<?= path_views(); ?>/favicon.ico" /><!-- favicon-->

    <!-- CSS -->
    <link rel="stylesheet" href="<?= path_views(); ?>/css/flick/jquery-ui-1.10.0.custom.min.css">
    <link rel="stylesheet" href="<?= path_views(); ?>/css/responsive.css">
    <link rel="stylesheet" href="<?= path_views(); ?>/css/public.css">

    <!-- JS -->
    <!--[if IE]> <script src="app/js/lib/html5.js"></script> <![endif]-->
    <script src="<?= path_views(); ?>/js/lib/jquery-1.9.1.js"></script>
    <script src="<?= path_views(); ?>/js/lib/all.custom.plugins.js"></script>    
    <script src="<?= path_views(); ?>/js/privates.js"></script>

    <!-- socials APIs -->
    

    <!-- Title -->
    <title><?= get_conf('titulo_site'); ?></title>
</head>
<body>
    <section class="barraTop">
        <article class="center">

            <div class="like-buttons">
                <!--<img src="<?= path_views(); ?>/img/bg-redes-sociais.jpg" height="31" width="350" alt="">-->
                <!-- AddThis Button BEGIN -->
                <div class="addthis_toolbox addthis_default_style ">
                <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
                <a class="addthis_button_tweet"></a>
                <a class="addthis_button_pinterest_pinit"></a>
                <a class="addthis_counter addthis_pill_style"></a>
                </div>
                <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5058bb69583933d4"></script>
                <!-- AddThis Button END -->
            </div>
            
            <div class="contatos">
                <p class="tel"><img src="<?= path_views(); ?>/img/ico-fone.png" alt="">Atendimento (63) 3217-1357</p>    
                <p class="address"><img src="<?= path_views(); ?>/img/ico-local.png" alt="">912 Sul Al 04 Lote 16 / palmas - TO</p>
            </div>

        </article>
        <!-- BarraTop -->
    </section>
    <header class="topo">
        <article class="center">
            <div class="logo">
                <h1>
                    <?= anchor('default/home', 'CarroAqui', array()); ?>
                </h1>
            </div>
            <nav class="nav-main">
                <ul>
                    <li><?= anchor('default/conteudo/ver/O-carro-aqui', 'O Carro Aqui', array('class'=>'nav-ativo')); ?></li>
                    <li><?= anchor('default/produtos', 'Nosso Estoque', array()); ?></li>
                    <li><?= anchor('default/contato', 'Fale Conosco', array()); ?></li>
                </ul>
            </nav>
            <form action="<?= site_url('default/produtos/busca');  ?>" method='post' class="form-busca-top">
                <label>
                    <input type="text" name="veiculo" placeholder="Faça uma busca" class="input-text">
                    <input type="submit" name="buscar" value="buscar" class="bt-busca-top">
                </label>
            </form>
            <div class="banners">
                <div class="left banner-left">
                    <?php 
                    $bannerEsquerdo = getBanners('TOPO_ESQUERDO');
                    echo $bannerEsquerdo[0]['banner']['montado'];
                    ?>
                </div>
                <div class="right banner-right">
                    <?php 
                    $bannerDireito = getBanners('TOPO_DIREITO');
                    echo $bannerDireito[0]['banner']['montado'];
                    ?>
                </div>
            </div>
            <div class="clear"></div>
        </article>
        <!-- header -->
    </header>
    <section class="container center clear">
        <section class="bloco-left left">
            <article class="shadow pesquisa-veiculos">
                <header>
                    <h1>PESQUISA DE VEICULOS</h1>
                </header>
                <form action="<?= site_url('default/produtos/busca');  ?>" method="post">
                    <div class="control">
                        <label for="">Veiculo:</label>
                        <input type="text" name="veiculo" class="input-text" value="" placeholder="Ex: Gol">
                    </div>
                    <div class="control control-mini-select">
                        <label for="">Ano:</label>
                        <select name="ano_fab">
                            <option value=""></option>
                            <?php
                            $arrAnoFab = listaAnoFab();
                            foreach($arrAnoFab as $fab){
                            ?>
                            <option value="<?= $fab['ano_fab']; ?>"><?= $fab['ano_fab']; ?></option>
                            <?php } ?>
                        </select>
                        <select name="ano_mod">
                            <option value=""></option>
                            <?php
                            $arrAnoMod = listaAnoMod();
                            foreach($arrAnoMod as $mod){
                            ?>
                            <option value="<?= $mod['ano_mod']; ?>"><?= $mod['ano_mod']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="control control-mini-select">
                        <label for="">Preço:</label>
                        <input type="text" name="valor_min" class="input-text" size="10" placeholder="De" style="width: 80px;">
                        <input type="text" name="valor_max" class="input-text" placeholder="Até" style="width: 80px;">
                    </div>
                    <div class="control control-estado">
                        <label for="">Estado:</label>
                        <select name="estado" id="estado" onchange="listaCidades();">
                            <option>Selecione o estado</option>
                            <?php
                            $arrEstados = listaEstados();
                            foreach($arrEstados as $est){
                            ?>
                            <option value="<?= $est['cod_estado']; ?>"><?= $est['titulo']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="control control-estado" id="lista_cidades">
                    </div>
                    <div class="control control-submit">
                        <input type="submit" name="" class="input-text" value="BUSCAR" placeholder="">
                    </div>
                </form>
                <div class="clear"></div>
                <!-- pesquisa de veiculo -->
            </article>
            <article class="shadow newsletter">
                <header>
                    <h1>RECEBA NOSSAS NOTICIAS</h1>
                </header>
                <form action="<?= site_url('default/newsletter');  ?>" method="post">
                    <div class="control">
                        <label for="">Nome:</label>
                        <input type="text" name="nome" class="input-text" value="">
                    </div>
                    <div class="control">
                        <label for="">Email:</label>
                        <input type="text" name="email" class="input-text" value="">
                    </div>
                    <div class="control control-submit">
                        <input type="submit" name="" class="input-text" value="Enviar">
                    </div>
                </form>
                <div class="clear"></div>
                <!-- newsletter -->
            </article>
            <article class="shadow links-diretos">
                <header>
                    <h1>LINKS DIRETOS</h1>
                </header>

                <nav class="">
                    <ul>
                        <?php
                        $arrLinks = listaLinks();
                        foreach ($arrLinks as $link){
                        ?>
                        <li><a href="<?= $link['link']; ?>" title="<?= $link['titulo']; ?>" target="_blank"><img src="<?= path_views(); ?>/img/ico-link-laranja.png" alt="<?= $link['titulo']; ?>"><?= $link['titulo']; ?></a></li>
                        <?php } ?>
                    </ul>
                </nav>
            </article>

            <!-- bloco left forms -->
        </section>

        <section class="bloco-right left">
                    
            <?= $conteudo;  ?>

            <!-- bloco-right -->
        </section>

        <!-- container -->
    </section>

    <div class="clear"></div>

    <section class="like-box">
        <article class="center">
            <figure>
                <!--<img src="<?= path_views(); ?>/img/like-box.jpg" alt="">-->
                <div class="fb-like-box fb_iframe_widget" data-href="http://www.facebook.com/platform" data-width="345" data-height="193" data-show-faces="true" data-stream="false" data-border-color="#e7e7e7" data-header="false" fb-xfbml-state="rendered"><span style="height: 193px; width: 345px;"><iframe id="f29aaadc9" name="f250458614" scrolling="no" style="border: none; overflow: hidden; height: 168px; width: 960px;" class="fb_ltr" src="http://www.facebook.com/plugins/likebox.php?api_key=&amp;locale=pt_BR&amp;sdk=joey&amp;channel=http%3A%2F%2Fstatic.ak.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D21%23cb%3Df2c8e5ebbc%26origin%3Dhttp%253A%252F%252Flifesites.com.br%252Ff24c62e88%26domain%3Dlifesites.com.br%26relation%3Dparent.parent&amp;height=168&amp;header=false&amp;show_faces=true&amp;stream=false&amp;width=960&amp;href=http%3A%2F%2Fwww.facebook.com%2Fplatform&amp;colorscheme=light&amp;border_color=%23e7e7e7&amp;show_border=true"></iframe></span></div>
            </figure>
        </article>
        <!-- like-box -->
    </section>

    <footer>
        <div class="center">
            <nav class="titles">
                <ul>
                    <li>INSTITUCIONAL</li>
                    <li>MAPA DO SITE</li>
                    <li>ATENDIMENTO</li>
                </ul>
            </nav>  
            <div class="clear"></div>
        </div>
        
        <span class="divisor"></span>

        <div class="center">
            <nav class="links nav-inst">
                <ul>
                    <li><?= anchor('default/conteudo/ver/Quem-somos', 'Quem somos', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Publicidade', 'Publicidade', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Imprensa', 'Imprensa', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Politica', 'Politica de Privacidade', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Termos-de-uso', 'Termos de Uso', array()); ?></li>
                </ul>
            </nav>

            <nav class="links nav-mapa">
                <ul>
                    <li><?= anchor('default/conteudo/ver/O-carro-aqui', 'O CarroAqui', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Financiamento', 'Financiamento', array()); ?></li>
                    <li><?= anchor('default/conteudo/ver/Servicos', 'Serviços', array()); ?></li>
                    <li><li><?= anchor('default/conteudo/ver/Atendimento', 'Atendimento', array()); ?></li></li>
                    <li><li><?= anchor('default/contato', 'Fale Conosco', array()); ?></li></li>
                </ul>
            </nav>

            <nav class="links nav-atend">
                <ul>
                    <li><li><?= anchor('default/conteudo/ver/Duvidas', 'Dúvidas', array()); ?></li></li>
                    <li><li><?= anchor('default/conteudo/ver/Como-comprar-veiculo', 'Como Comprar seu Veiculo', array()); ?></li></li>
                    <li><li><?= anchor('default/conteudo/ver/Como-vender-veiculo', 'Como Vender seu Veiculo', array()); ?></li></li>
                </ul>
            </nav>
            <div class="clear"></div>
        </div>
    </footer>

    <section class="assinatura">
        <article class="center">
            <span>®2013 - 2013 - Todos os direitos reservados</span>
            <figure>
                <a href="http://lifesites.com.br">
                    <img src="<?= path_views(); ?>/img/logo-life.png" alt="">
                </a>
            </figure>
        </article>
    </section>
    <script>
        function listaCidades(){
            var param = {cod_estado:$('#estado').val()}
            $('#lista_cidades').load("<?= site_url('admin/cidades/showListaCidades'); ?>", param);
        }
    </script>
    <script src="http://connect.facebook.net/pt_BR/all.js#xfbml=1" charset="utf-8"></script>
</body>
</html>