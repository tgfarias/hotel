
<section class="destaque-mes">
    <header>
        <h1><img src="<?= path_views(); ?>/img/ico-relampago.png" alt="">DESTAQUE DO MÊS</h1>
    </header>

    <article class="shadow destaque">
        <a href="<?= site_url('default/produtos/ver'); ?>">
            <figure>
                <div class="title">
                    <p>Camaro Branco do Transformers</p>
                    <br>
                    <p>Valor: R$ 32.990,00</p>
                    <br>
                    <p>Super Promoção</p>
                </div>

                <img src="" alt="" />

            </figure>
        </a>
    </article>
    <!-- destaques-mes -->
</section>

<section class="ofertas-dia">
    <header>
        <h1><img src="<?= path_views(); ?>/img/ico-oferta.png" alt="">OFERTAS DO DIA</h1>
    </header>
    <article class="ofertas">
        <!-- Laço das ofertas do dia -->
        <?php 
        $destaque = listaVeiculosDestaque();
        foreach($destaque as $dest){ 
            ?>
            <div class="shadow item">
                <figure>
                    <img src="<?= base_url('midia/veiculos/'.$dest['fotos'][0]['pasta']).'/'.$dest['fotos'][0]['foto']; ?>" alt="">
                </figure>
                <div class="title">
                    <p><?= $dest['nome']; ?></p>
                </div>
                <div class="valor">
                    <p>Valor: R$ <?= formata_valor($dest['valor']); ?></p>
                </div>
                <?= anchor('default/produtos/ver/'.$dest['cod_veiculo'], '<img src="'.path_views().'/img/ico-estrela.png" alt=""> Mais detalhes', array('class'=>'more')); ?>
                <div class="clear"></div>                       
            </div>
            <?php 
        }
        ?>
    </article>
    <!-- destaques-mes -->
</section>