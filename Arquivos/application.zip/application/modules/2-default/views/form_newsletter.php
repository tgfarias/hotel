<section class="ver-conteudo">

    <header>
        <h1>Newsletter</h1>
    </header>
    
    <div class="contato newsletter">
        <form action="<?= site_url('default/newsletter'); ?>" method="post" class="form-fale">
            <span class="danger-notice"> * Atenção todos os campos são obrigátorios.</span>
            
            <label for=""> 
                <p class="post">Nome:</p>
                <input type="text" name="nome" class="border5">
                <?php echo form_error('nome', '<p class="error">', '</p>'); ?>
            </label>
            
            <label for="">
                <p class="post">Email:</p>
                <input type="text" name="email" class="border5">
                <?php echo form_error('email', '<p class="error">', '</p>'); ?>
            </label>
            
            <label for="">
                <p class="post"></p>
                <input type="submit" class="" value="Cadastrar">
            </label>
            
        </form>

        <div class="clear"></div>
</section>

<section class="ofertas-dia">
    <header>
        <h1><img src="<?= path_views(); ?>/img/ico-oferta.png" alt="">OFERTAS DO DIA</h1>
    </header>

    <article class="ofertas">
        <!-- Laço das ofertas do dia -->
        <?php 
        $destaque = listaVeiculosDestaque();
        foreach($destaque as $dest){ 
            ?>
            <div class="shadow item">
                <figure>
                    <img src="<?= base_url('midia/veiculos/'.$dest['fotos'][0]['pasta']).'/'.$dest['fotos'][0]['foto']; ?>" alt="">
                </figure>
                <div class="title">
                    <p><?= $dest['nome']; ?></p>
                </div>
                <div class="valor">
                    <p>Valor: R$ <?= formata_valor($dest['valor']); ?></p>
                </div>
                <?= anchor('default/produtos/ver/'.$dest['cod_veiculo'], '<img src="'.path_views().'/img/ico-estrela.png" alt=""> Mais detalhes', array('class'=>'more')); ?>
                <div class="clear"></div>                       
            </div>
            <?php 
        }
        ?>
    </article>
    <!-- destaques-mes -->
</section>