<section class="ofertas-dia resultado-busca">
    <header>
        <h1>RESULTADOS DA BUSCA</h1>
    </header>
    <article class="resultados">
        <table>
            <tr>
                <td>Imagem</td>
                <td>Nome</td>
                <td>Valor</td>
                <td>Data</td>
            </tr>
            <?php 
            //$arrEstoque = listaEstoque();
            $total = 0;
            foreach ($resultado->result() as $row) { 
            $arrFotos = listaFotosVeiculo($row->cod_veiculo);    
            ?>
            <tr>
                <td class="image">
                    <img src="<?= base_url('midia/veiculos/'.$arrFotos[0]['pasta']).'/'.$arrFotos[0]['foto']; ?>" />
                </td>
                <td>
                    <?= anchor('default/produtos/ver/'.$row->cod_veiculo, $row->nome.' ('.$row->ano_fab.'/'.$row->ano_mod.')'); ?><br/>
                    <?= $row->cor; ?> - <?= $row->combustivel; ?>
                </td>
                <td>R$ <?= formata_valor($row->valor); ?></td>
                <td> <?= mdate('%d/%m/%Y', strtotime($row->data_cadastro)); ?></td>
            </tr>
            <?php 
            $total++;
            }
            ?>
            <tr>
                <td class="image"></td>
                <td></td>
                <td></td>
                <td style="font-weight: bold">Encontrados : <?= $total; ?></td>
            </tr>
        </table>
        <div class="clear"></div>                       
    </div>
</article>
<!-- destaques-mes -->
</section>