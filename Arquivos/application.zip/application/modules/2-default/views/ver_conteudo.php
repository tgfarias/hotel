
<?php 
$conteudo = getConteudoByLink($link);
?>

<section class="ver-conteudo">
    <header>
        <h1><?= $conteudo['cnt_titulo'];  ?></h1>
    </header>

    <article class="resultados">
       <?= $conteudo['cnt_conteudo'];  ?>
    </article>
    <!-- destaques-mes -->
</section>