<?php $veiculo = detalheVeiculo($cod_veiculo); ?>
<section class="destaque-mes view-veiculo">
    <header>
        <h1><?= $veiculo['nome']; ?></h1>
    </header>
    <article class="shadow destaque veiculo">
        <figure>
             <img src="<?= base_url('midia/veiculos/'.$veiculo['fotos'][0]['pasta']).'/'.$veiculo['fotos'][0]['foto']; ?>" alt="">
        </figure>
    </article>
    <nav class="thumbs">
        <ul>
            <?php 
            $arrFotos = listaFotosVeiculo($cod_veiculo);
            foreach ($arrFotos as $foto) { ?>
            <li>
                <img src="<?= base_url('midia/veiculos/'.$foto['pasta']).'/'.$foto['foto']; ?>" alt="">
            </li>
            <?php } ?>
        </ul>
    </nav>
    <section class="descricao">
        <nav class="">
            <ul>
                <li>
                    <span class="desc">Veículo:</span>
                    <span class="valor"><?= $veiculo['nome']; ?></span>
                </li>
                <li>
                    <span class="desc">Marca:</span>
                    <span class="valor"><?= $veiculo['cod_marca']; ?></span>
                </li>
                <li>
                    <span class="desc">Ano / Modelo:</span>
                    <span class="valor"><?= $veiculo['ano_fab'].' / '.$veiculo['ano_mod']; ?></span>
                </li>
                <li>
                    <span class="desc">Cor:</span>
                    <span class="valor"><?= $veiculo['cor']; ?></span>
                </li>
                <li>
                    <span class="desc">Motorização:</span>
                    <span class="valor"><?= $veiculo['motor']; ?></span>
                </li>
                <li>
                    <span class="desc">Combustivel:</span>
                    <span class="valor"><?= $veiculo['combustivel']; ?></span>
                </li>
                <li>
                    <span class="desc">Opcionais:</span>
                    <span class="valor">
                        <?php 
                        
                        if($veiculo['arcond']){ echo 'Ar-condicionado, '; }
                        if($veiculo['direcao']){ echo 'Direção hidráulica,'; }
                        if($veiculo['alarme']){ echo 'Alarme,'; }
                        if($veiculo['vidro']){ echo 'Vidros elétricos,'; }
                        
                        ?>
                    </span>
                </li>
                <li>
                    <span class="desc">Observações:</span>
                    <span class="valor"><?= $veiculo['observacoes']; ?></span>
                </li>
                <li>
                    <span class="desc">Valor:</span>
                    <span class="valor"> R$ <?= formata_valor($veiculo['valor']); ?></span>
                </li>
            </ul>
        </nav>
    </section>
    <div class="clear"></div>
    <!-- destaques-mes -->
</section>
<section class="ofertas-dia">
    <header>
        <h1><img src="<?= path_views(); ?>/img/ico-oferta.png" alt="">OFERTAS DO DIA</h1>
    </header>
    <article class="ofertas">
        <!-- Laço das ofertas do dia -->
        <?php 
        $destaque = listaVeiculosDestaque();
        foreach($destaque as $dest){ 
            ?>
            <div class="shadow item">
                <figure>
                    <img src="<?= base_url('midia/veiculos/'.$dest['fotos'][0]['pasta']).'/'.$dest['fotos'][0]['foto']; ?>" alt="">
                </figure>
                <div class="title">
                    <p><?= $dest['nome']; ?></p>
                </div>
                <div class="valor">
                    <p>Valor: R$ <?= formata_valor($dest['valor']); ?></p>
                </div>
                <?= anchor('default/produtos/ver/'.$dest['cod_veiculo'], '<img src="'.path_views().'/img/ico-estrela.png" alt=""> Mais detalhes', array('class'=>'more')); ?>
                <div class="clear"></div>                       
            </div>
            <?php 
        }
        ?>
    </article>
    <!-- destaques-mes -->
</section>
