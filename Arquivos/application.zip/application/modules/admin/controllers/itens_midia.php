<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela tb_itens_midia 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */

class itens_midia extends MX_Controller {

    private $painel_name = 'itens_midia';

    function __construct() {
        parent::__construct();
        only_user();
        $this->load->model($this->painel_name . '_model');
        $this->load->model('midias_model');
    }

    /**
     * Este método mostra a lista de registros da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function index($cod_midia) {
        $config = array();
        $dados_painel = array();
        $limit = 25;
        $uri_segment = 6;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/' . $this->painel_name . '/index/' . $cod_midia . '/pag');
        $total_registros = $this->itens_midia_model->count_all($cod_midia);
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->itens_midia_model->get_paged_list($cod_midia, $limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $dados_painel['cod_midia'] = $cod_midia;
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de cadastro da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function insert($cod_midia) {
        $midia = $this->midias_model->get_by_id($cod_midia)->row();
        $dados_painel['modo'] = 'insert';
        $dados_painel['cod_midia'] = $cod_midia;
        $dados_painel['tipo_midia'] = $midia->mid_tipo;
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de alteração da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function update($id = '') {
        if ($id == '')
            redirect('admin/' . $this->painel_name);
        $dados_painel['modo'] = 'update';
        $dados_painel['row'] = $this->itens_midia_model->get_by_id($id)->row();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método salva o registro na tabela tb_itens_midia.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * Este método também avalia a situação do upload da mídia, sendo que
     * para cada tipo de mídia ele tem uma ação diferente:
     * 
     * - Youtube: Não cadastra mídia, apenas o conteúdo HTML fornecido;
     * - Massa: Cadastra imagens em massa, neste caso sem descrição nem título;
     * - Imagem: Cadastra as imagens normalmente uma a uma, mas com a descrição completa;
     * - Arquivos: Cadastra os demais tipos de arquivo um a um;
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function save($id = '') {

        $this->load->model('midias_model');

        $cod_midia = $_POST['cod_midia'];
        $midia = $this->midias_model->get_by_id($cod_midia)->row();
        $tipo = $midia->mid_tipo;
        $pasta = $id; //$midia->mid_pasta;

        $dados_save['itm_tipo'] = $tipo;
        $dados_save['itm_data_cad'] = mdate('%Y-%m-%d', strtotime($_POST['itm_data_cad']));
        $dados_save['itm_publicado'] = $_POST['itm_publicado'];

        /**
         * Verifica se deve inserir um novo registro ou atualizar um
         * registro existente.
         */
        if ($id):

            $dados_save['itm_titulo'] = $_POST['itm_titulo'];
            $dados_save['itm_descricao'] = $_POST['itm_descricao'];
            $dados_save['itm_conteudo'] = $_POST['itm_conteudo'];

            if (isset($_POST['alterar_arquivo'])):
                if ($_POST['itm_tipo'] != 'Youtube'):
                    $this->_del_file($id);
                    $dados_save['itm_file_name'] = $this->_upload($pasta);
                endif;
            endif;

            if ($this->itens_midia_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name . '/index/' . $cod_midia, 'script');
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/' . $this->painel_name . '/index/' . $cod_midia, 'script');
            endif;
        else:
            $dados_save['itm_views'] = 0 ;
            switch ($tipo) :
                case 'Massa' :
                    $dados_save['itm_titulo'] = 'Cadastro em massa.';
                    $dados_save['itm_descricao'] = NULL;
                    $dados_save['itm_conteudo'] = NULL;
                    $dados_save['cod_midia'] = $cod_midia;
                    $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
                    $dados_save['itm_pasta'] = $pasta;

                    /**
                     * Inicia o processo de upload múltiplo.
                     */
                    $i = 0;
                    $arquivos = array(array());
                    foreach ($_FILES as $key => $info):
                        foreach ($info as $key => $dados):
                            for ($i = 0; $i < sizeof($dados); $i++):
                                $arquivos[$i][$key] = $info[$key][$i];
                            endfor;
                        endforeach;
                    endforeach;

                    $i = 1;
                    $sucessos = '';
                    foreach ($arquivos as $file):
                        if ($file['name'] != ''):
                            if (preg_match("/^image\/(gif|jpeg|jpg|png)$/", $file['type'])):
                                $caminho_completo = './midia/galerias/' . $pasta . '/';
                                $caminho_completo = str_replace("\\", "/", realpath($caminho_completo)) . '/' . $file['name'];
                                if (move_uploaded_file($file['tmp_name'], $caminho_completo)):
                                    $sucessos = $sucessos + 1;
                                    $dados_save['itm_file_name'] = $file['name'];
                                    $this->itens_midia_model->save($dados_save);
                                else:
                                    $erros = $erros + 1;
                                endif;
                            endif;
                        endif;
                        $i++;
                    endforeach;

                    $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                    redirect('admin/' . $this->painel_name . '/index/' . $cod_midia);

                    break;

                case 'Youtube' :
                    $dados_save['itm_titulo'] = $_POST['itm_titulo'];
                    $dados_save['itm_descricao'] = $_POST['itm_descricao'];
                    $dados_save['itm_conteudo'] = $_POST['itm_conteudo'];
                    $dados_save['cod_midia'] = $cod_midia;
                    $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
                    $dados_save['itm_pasta'] = NULL;
                    $dados_save['itm_file_name'] = NULL;
                    if ($this->itens_midia_model->save($dados_save)):
                        $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                        redirect('admin/' . $this->painel_name . '/index/' . $cod_midia, 'script');
                    else:
                        $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                        redirect('admin/' . $this->painel_name . '/index/' . $cod_midia, 'script');
                    endif;
                    break;

                default :
                    $dados_save['itm_titulo'] = $_POST['itm_titulo'];
                    $dados_save['itm_descricao'] = $_POST['itm_descricao'];
                    $dados_save['itm_conteudo'] = NULL;
                    $dados_save['cod_midia'] = $cod_midia;
                    $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
                    $dados_save['itm_pasta'] = $pasta;
                    $dados_save['itm_file_name'] = $this->_upload($pasta);
                    if ($this->itens_midia_model->save($dados_save)):
                        $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                        redirect('admin/' . $this->painel_name . '/index/' . $cod_midia);
                    else:
                        $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                        redirect('admin/' . $this->painel_name . '/index/' . $cod_midia);
                    endif;
                    break;
                    
            endswitch;
        endif;
    }

    /**
     * Este método exclui um registro da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function delete($cod_item_midia, $cod_midia) {

        $this->_del_file($cod_item_midia);

        if ($this->itens_midia_model->delete($cod_item_midia)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
            redirect('admin/' . $this->painel_name . '/index/' . $cod_midia);
        else:
            $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
            redirect('admin/' . $this->painel_name . '/index/' . $cod_midia);
        endif;
    }

    /**
     * Este método faz o upload de uma imagem de capa.
     * 
     * @access private
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return mixed 
     */
    private function _upload($pasta) {
        // Configura o upload
        $config['upload_path'] = './midia/galerias/' . $pasta . '/';
        $config['allowed_types'] = 'gif|jpg|png|mp3|rar|zip|pdf|tar|tar.gz|exe|zip|xml|mdb|asx|js|gz|hlp|ppt|pps|pot|xlw|xlt|xls|xml|xlc|xla|rtf|pdf|exe|class|bin|doc|docx|au|snd|mid|rmi|mp3|m3u|ra|ram|wav|zip|asp|php|css|htm|html|stm|bas|txt|rtx|htc|xml'; //'gif|jpg|png|mp3|rar|zip|pdf|tar|tar.gz|exe';
        $config['max_size'] = '9900000000';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['remove_spaces'] = TRUE;
        $config['overwrite'] = TRUE;
        // Carrega a biblioteca passando as configurações
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()):
            return NULL;
        else:
            $capa = $this->upload->data();
            return $capa['file_name'];
            ;
        endif;
    }

    /**
     * Este método exclui um arquivo de mídia da pasta para liberar recursos do
     * servidor evitando o acúmulo de lixo. O método faz a verificação se o
     * arquivo existe fisicamente antes de efetuar a exclusão.
     * 
     * @access private
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $cod_item_midia
     * @return boolean 
     */
    private function _del_file($cod_item_midia) {
        $this->load->model('itens_midia_model');
        $query = $this->itens_midia_model->get_by_id($cod_item_midia)->row();
        if (file_exists('./midia/galerias/' . $query->itm_pasta . '/' . $query->itm_file_name)):
            if (unlink('./midia/galerias/' . $query->itm_pasta . '/' . $query->itm_file_name)):
                return TRUE;
            else:
                return FALSE;
            endif;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

