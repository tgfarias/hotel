<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela tb_banners 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 28/07/2012 
 * @version 0.0.1 
 * 
 */

class banners extends MX_Controller {

    private $painel_name = 'banners';

    function __construct() {
        parent::__construct();
        $this->load->model($this->painel_name . '_model');
    }

    /**
     * Este método mostra a lista de registros da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function index() {
        $config = array();
        $dados_painel = array();
        $limit = 25;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/' . $this->painel_name . '/index/pag');
        $total_registros = $this->banners_model->count_all();
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->banners_model->get_paged_list($limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de cadastro da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function insert() {
        $dados_painel['modo'] = 'insert';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de alteração da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function update($id = '') {
        if ($id == '')
            redirect('admin/' . $this->painel_name);
        $dados_painel['modo'] = 'update';
        $dados_painel['row'] = $this->banners_model->get_by_id($id)->row();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método salva o registro na tabela tb_banners.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function save($id = '') {

        $dados_save['ban_titulo'] = $_POST['ban_titulo'];
        $dados_save['ban_posicao'] = $_POST['ban_posicao'];
        $dados_save['ban_ordem'] = $_POST['ban_ordem'];
        $dados_save['ban_link'] = $_POST['ban_link'];
        $dados_save['ban_tipo'] = $_POST['ban_tipo'];
        $dados_save['ban_html'] = $_POST['ban_html'];
        if(isset($_POST['ban_data_expira']))$dados_save['ban_data_expira'] = mdate('%Y-%m-%d', strtotime($_POST['ban_data_expira']));

        if (isset($_POST['ban_ativo'])):
            $dados_save['ban_ativo'] = $_POST['ban_ativo'];
        else:
            $dados_save['ban_ativo'] = '0';
        endif;
        /**
         * Caso seja informado um ID, efetua-se uma alteração, caso não seja
         * informado efetua-se um novo cadastro.
         */
        if ($id):
            $dados_save['ban_click'] = $_POST['ban_click'];
            $dados_save['ban_views'] = $_POST['ban_views'];
            $dados_save['ban_width'] = $_POST['ban_width'];
            $dados_save['ban_height'] = $_POST['ban_height'];
            if (isset($_POST['alterar_arquivo'])):
                $this->_del_file($id);
                $upload = $this->_upload();
                $dados_save['ban_arquivo'] = $upload['file_name'];
            endif;
            if ($this->banners_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/' . $this->painel_name);
            endif;
        else:
            // Faz o upload do arquivo e recupera o array com as informações.
            $upload = $this->_upload();
            $dados_save['ban_click'] = 0;
            $dados_save['ban_views'] = 0;
            $dados_save['ban_data_cad'] = date("Y-m-d H:i:s");
            $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
            $dados_save['ban_arquivo'] = $upload['file_name'];
            if(!isset($_POST['ban_width'])){
                $dados_save['ban_width'] = $upload['image_width'];
            } else {
                $dados_save['ban_width'] = $_POST['ban_width'];
            }
            if(!isset($_POST['ban_height'])){
                $dados_save['ban_height'] = $upload['image_height'];
            } else {
                $dados_save['ban_height'] = $_POST['ban_height'];
            }

            if ($this->banners_model->save($dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                redirect('admin/' . $this->painel_name);
            endif;
        endif;
    }

    /**
     * Este método exclui um registro da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function delete($id) {
        if ($this->banners_model->delete($id)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
            redirect('admin/' . $this->painel_name);
        else:
            $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
            redirect('admin/' . $this->painel_name);
        endif;
    }

    /**
     * Este método faz o upload de uma imagem de capa.
     * 
     * @access private
     * @return mixed 
     */
    private function _upload() {
        // Configura o upload
        $config['upload_path'] = './midia/banners/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['max_size'] = '0';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['remove_spaces'] = TRUE;
        $config['overwrite'] = TRUE;
        $config['file_name'] = md5(date('d-m-Y H:i:s'));
        // Carrega a biblioteca passando as configurações
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload()):
            return NULL;
        else:
            return $this->upload->data();
        endif;
    }

    /**
     * Este método verifica se um registro tem imagem cadastrada, em
     * seguida verifica se a imagem existe na pasta de mídia e 
     * se tiver exclui o arquivo físico.
     * 
     * @access private
     * @param int $id
     * @return boolean 
     */
    private function _del_file($id) {
        $query = $this->banners_model->get_by_id($id)->row();
        $arquivo = $query->ban_arquivo;
        if ($arquivo):
            if (file_exists('./midia/banners/' . $arquivo)):
                if (unlink('./midia/banners/' . $arquivo)):
                    return TRUE;
                else:
                    return FALSE;
                endif;
            endif;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */