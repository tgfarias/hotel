<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela veiculos 
 * 
 * @package CMS 
 * @author Gerado automaticamente - <contato@elieldepaula.com.br> 
 * @since 03/04/2013 
 * @version 0.0.1 
 * 
 */
class veiculos extends MX_Controller {

    private $painel_name = 'veiculos';

    function __construct() {
        parent::__construct();
        $this->load->model($this->painel_name . '_model');
        $this->load->helper('veiculos');
    }

    /**
     * Este método mostra a lista de registros da tabela veiculos.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function index() {
        $config = array();
        $dados_painel = array();
        $limit = 20;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/' . $this->painel_name . '/index/pag');
        $total_registros = $this->veiculos_model->count_all();
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->veiculos_model->get_paged_list($limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de cadastro da tabela veiculos.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function insert() {
        $dados_painel['modo'] = 'insert';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de alteração da tabela veiculos.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function update($id = '') {
        if ($id == '')
            redirect('admin/' . $this->painel_name);
        $dados_painel['modo'] = 'update';
        $dados_painel['row'] = $this->veiculos_model->get_by_id($id)->row();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método salva o registro na tabela veiculos.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function save($id = '') {

        $veiculo = $_POST['nome'];

        $dados_save['cod_tipo_veiculo'] = $_POST['cod_tipo_veiculo'];
        $dados_save['cod_marca'] = $_POST['cod_marca'];
        $dados_save['cod_cidade'] = $_POST['cod_cidade'];
        $dados_save['nome'] = $veiculo;
        $dados_save['cor'] = $_POST['cor'];
        $dados_save['ano_fab'] = $_POST['ano_fab'];
        $dados_save['ano_mod'] = $_POST['ano_mod'];
        $dados_save['motor'] = $_POST['motor'];
        $dados_save['combustivel'] = $_POST['combustivel'];

        if (isset($_POST['arcond'])) {
            $dados_save['arcond'] = 1;
        } else {
            $dados_save['arcond'] = 0;
        }

        if (isset($_POST['alarme'])) {
            $dados_save['alarme'] = 1;
        } else {
            $dados_save['alarme'] = 0;
        }

        if (isset($_POST['direcao'])) {
            $dados_save['direcao'] = 1;
        } else {
            $dados_save['direcao'] = 0;
        }

        if (isset($_POST['vidro'])) {
            $dados_save['vidro'] = 1;
        } else {
            $dados_save['vidro'] = 0;
        }

        if (isset($_POST['ativo'])) {
            $dados_save['ativo'] = 1;
        } else {
            $dados_save['ativo'] = 0;
        }
        if (isset($_POST['destaque'])) {
            $dados_save['destaque'] = 1;
        } else {
            $dados_save['destaque'] = 0;
        }

        $dados_save['observacoes'] = $_POST['observacoes'];
        $dados_save['data_cadastro'] = mdate('%Y-%m-%d', strtotime($_POST['data_cadastro']));
        $dados_save['valor'] = $_POST['valor'];

        if ($id):
            if ($this->veiculos_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/' . $this->painel_name);
            endif;
        else:

            $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
            $cod_veiculo = $this->veiculos_model->save($dados_save);

            if ($cod_veiculo):

                $this->load->model('fotos_veiculo_model');

                $pasta_veiculo = url_title($cod_veiculo . $veiculo);
                mkdir('./midia/veiculos/' . $pasta_veiculo, 0777);

                /* Inicia o upload das imagens. */
                $i = 0;
                $arquivos = array(array());
                foreach ($_FILES as $key => $info):
                    foreach ($info as $key => $dados):
                        for ($i = 0; $i < sizeof($dados); $i++):
                            $arquivos[$i][$key] = $info[$key][$i];
                        endfor;
                    endforeach;
                endforeach;

                $i = 1;
                $sucessos = '';
                foreach ($arquivos as $file):
                    if ($file['name'] != ''):
                        if (preg_match("/^image\/(gif|jpeg|jpg|png)$/", $file['type'])):
                            $caminho_completo = './midia/veiculos/' . $pasta_veiculo . '/';
                            $caminho_completo = str_replace("\\", "/", realpath($caminho_completo)) . '/' . $file['name'];
                            if (move_uploaded_file($file['tmp_name'], $caminho_completo)):
                                $sucessos = $sucessos + 1;
                                $dados_foto['cod_veiculo'] = $cod_veiculo;
                                $dados_foto['pasta'] = $pasta_veiculo;
                                $dados_foto['foto'] = $file['name'];
                                $this->fotos_veiculo_model->save($dados_foto);
                            else:
                                $erros = $erros + 1;
                            endif;
                        endif;
                    endif;
                    $i++;
                endforeach;
                /* Encerra o upload das imagens. */

                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);

            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                redirect('admin/' . $this->painel_name);
            endif;
        endif;
    }

    /**
     * Este método exclui um registro da tabela veiculos.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function delete($id) {

        //TODO Criar a exclusão das fotos antes de excluir o veículo.

        if ($this->veiculos_model->delete($id)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
            redirect('admin/' . $this->painel_name);
        else:
            $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
            redirect('admin/' . $this->painel_name);
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

