<?php 

if ( ! defined('BASEPATH')) exit('Acesso direto ao script negado.'); 

/** 
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela fotos_veiculo 
 * 
 * @package CMS 
 * @author Gerado automaticamente - <contato@elieldepaula.com.br> 
 * @since 03/04/2013 
 * @version 0.0.1 
 * 
 */

class fotos_veiculo extends MX_Controller { 

    private $painel_name = 'fotos_veiculo';

    function __construct() {
        parent::__construct();
        $this->load->model($this->painel_name.'_model');
        $this->load->helper('veiculos');
    }

    /**
     * Este método mostra a lista de registros da tabela fotos_veiculo.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function index() {
        $config = array();
        $dados_painel = array();
        $limit = 10;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/'.$this->painel_name.'/index/pag');
        $total_registros = $this->fotos_veiculo_model->count_all();
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->fotos_veiculo_model->get_paged_list($limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $this->template->load('main_view', $this->painel_name.'_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de cadastro da tabela fotos_veiculo.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function insert($cod_veiculo) {
        $dados_painel['modo'] = 'insert';
        $dados_painel['cod_veiculo'] = $cod_veiculo;
        $this->template->load('main_view', $this->painel_name.'_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de alteração da tabela fotos_veiculo.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function update($id = ''){
        if($id=='')redirect('admin/'.$this->painel_name);
        $dados_painel['modo'] = 'update';
        	$dados_painel['row'] = $this->fotos_veiculo_model->get_by_id($id)->row();
        	$this->template->load('main_view', $this->painel_name.'_view', $dados_painel);
    }

    /**
     * Este método salva o registro na tabela fotos_veiculo.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function save($id = '') {
        
        if($id):
            
            // recupera os detalhes da foto.
            $detalhes = $this->fotos_veiculo_model->get_by_id($id)->row();
            // Verifica se deve ou não alterar a imagem
            if($_POST['alterar_imagem'] == '1'){
                $dados_save['foto'] = $this->_upload($detalhes->pasta);
            }
            // Efetua a alteração no banco de dados.
            if($this->fotos_veiculo_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/veiculos/update/'.$id);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/veiculos/update/'.$id);
            endif;
            
        else:
            // Recupera o código do veículo.
            $cod_veiculo = $_POST['cod_veiculo'];
            // Recupera os dados do veículo e usa o nome para ver o nome da pasta.
            $this->load->model('veiculos_model');
            $veiculo = $this->veiculos_model->get_by_id($cod_veiculo)->row();
            // Define o nome da pasta.
            $pasta_veiculo = url_title($cod_veiculo . $veiculo->nome);
            // Monta o array de cadastro.
            $dados_save['cod_veiculo'] = $cod_veiculo;
            $dados_save['pasta'] = $pasta_veiculo;
            $dados_save['foto'] = $this->_upload($pasta_veiculo);
            // Efetua o processo de cadastro no banco de dados.
            if($this->fotos_veiculo_model->save($dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/veiculos/update/'.$cod_veiculo);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                redirect('admin/veiculos/update/'.$cod_veiculo);
            endif;
            
        endif;
    }

    /**
     * Este método exclui um registro da tabela fotos_veiculo.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function delete($id) {
        
        $detalhes = $this->fotos_veiculo_model->get_by_id($id)->row();
        
        if($this->fotos_veiculo_model->delete($id)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
    	       redirect('admin/veiculos/update/'.$detalhes->cod_veiculo);
    	   else:
    	       $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
                redirect('admin/veiculos/update/'.$detalhes->cod_veiculo);
    	   endif;
    }
    
    private function _upload($pasta) {
        // Configura o upload
        $config['upload_path'] = './midia/veiculos/' . $pasta . '/';
        $config['allowed_types'] = 'gif|jpg|png|mp3|rar|zip|pdf|tar|tar.gz|exe|zip|xml|mdb|asx|js|gz|hlp|ppt|pps|pot|xlw|xlt|xls|xml|xlc|xla|rtf|pdf|exe|class|bin|doc|docx|au|snd|mid|rmi|mp3|m3u|ra|ram|wav|zip|asp|php|css|htm|html|stm|bas|txt|rtx|htc|xml'; //'gif|jpg|png|mp3|rar|zip|pdf|tar|tar.gz|exe';
        $config['max_size'] = '9900000000';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['remove_spaces'] = TRUE;
        $config['overwrite'] = TRUE;
        // Carrega a biblioteca passando as configurações
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()):
            return NULL;
        else:
            $capa = $this->upload->data();
            return $capa['file_name'];
            ;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

