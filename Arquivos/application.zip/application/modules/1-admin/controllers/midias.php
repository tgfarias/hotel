<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela tb_midias 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */

class midias extends MX_Controller {

    private $painel_name = 'midias';

    function __construct() {
        parent::__construct();
        only_user();
        $this->load->model($this->painel_name . '_model');
    }

    /**
     * Este método mostra a lista de registros da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function index() {
        $config = array();
        $dados_painel = array();
        $limit = 25;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/' . $this->painel_name . '/index/pag');
        $total_registros = $this->midias_model->count_all();
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->midias_model->get_paged_list($limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de cadastro da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function insert() {
        $dados_painel['modo'] = 'insert';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método exibe o formulário de alteração da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function update($id = '') {
        if ($id == '')
            redirect('admin/' . $this->painel_name);
        $dados_painel['modo'] = 'update';
        $dados_painel['row'] = $this->midias_model->get_by_id($id)->row();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este método salva o registro na tabela tb_midias.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function save($id = '') {

        $dados_save['mid_titulo'] = $_POST['mid_titulo'];
        $dados_save['mid_link'] = url_title($_POST['mid_titulo']);
		$dados_save['mid_descricao'] = $_POST['mid_descricao'];
        $dados_save['mid_data_cad'] = mdate('%Y-%m-%d', strtotime($_POST['mid_data_cad']));
        
		if(isset($_POST['mid_tipo'])){
			$dados_save['mid_tipo'] = $_POST['mid_tipo'];
		} else {
			$dados_save['mid_tipo'] = 'Massa';
		}
        
        if(isset($_POST['mid_destaque'])){
            $dados_save['mid_destaque'] = 1;
        } else {
            $dados_save['mid_destaque'] = 0;
        }
        
        if(isset($_POST['mid_comentario'])){
            $dados_save['mid_comentario'] = 1;
        } else {
            $dados_save['mid_comentario'] = 0;
        }
        
        if(isset($_POST['mid_publicado'])){
            $dados_save['mid_publicado'] = 1;
        } else {
            $dados_save['mid_publicado'] = 0;
        }

        if ($id):

            if ($_POST['alterar_capa']):
                $this->_del_file($id);
                $dados_save['mid_capa'] = $this->_upload();
            endif;

            if ($this->midias_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/' . $this->painel_name);
            endif;

        else:
            // Se for galeria de vídeos não cria a pasta.
            if ($_POST['mid_tipo'] <> 'Youtube'):
                $nova_pasta = character_limiter(md5($_POST['mid_titulo']), '35');
                mkdir('./midia/galerias/' . $nova_pasta, 0777);
            endif;

            $dados_save['mid_capa'] = $this->_upload();
            $dados_save['mid_pasta'] = $nova_pasta;
            $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');

            if ($this->midias_model->save($dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name);
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                redirect('admin/' . $this->painel_name);
            endif;

        endif;
    }

    /**
     * Este método exclui um registro da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function delete($id) {

        $this->_del_file($id);

        if ($this->midias_model->delete($id)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
            redirect('admin/' . $this->painel_name);
        else:
            $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
            redirect('admin/' . $this->painel_name);
        endif;
    }

    /**
     * Este método faz o upload de uma imagem de capa.
     * 
     * @access private
     * @return mixed 
     */
    private function _upload() {
        // Configura o upload
        $config['upload_path'] = './midia/capas/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '0';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['remove_spaces'] = TRUE;
        $config['overwrite'] = TRUE;
        // Carrega a biblioteca passando as configurações
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()):
            return NULL;
        else:
            $capa = $this->upload->data();
            return $capa['file_name'];
            ;
        endif;
    }

    /**
     * Este método verifica se um registro tem imagem cadastrada, em
     * seguida verifica se a imagem existe na pasta de mídia e 
     * se tiver exclui o arquivo físico.
     * 
     * @access private
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $id
     * @return boolean 
     */
    private function _del_file($id) {
        $query = $this->midias_model->get_by_id($id)->row();
        $arquivo = $query->mid_capa;
        if (file_exists('./midia/capas/' . $arquivo)):
            if (unlink('./midia/capas/' . $arquivo)):
                return TRUE;
            else:
                return FALSE;
            endif;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

