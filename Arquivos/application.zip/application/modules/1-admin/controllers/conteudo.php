<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o controller da tabela tb_conteudo 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */

class conteudo extends MX_Controller {

    private $painel_name = 'conteudo';

    function __construct() {
        parent::__construct();
        only_user();
        $this->load->model($this->painel_name . '_model');
    }

    /**
     * Este m�todo mostra a lista de registros da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function index() {
        $config = array();
        $dados_painel = array();
        $limit = 25;
        $uri_segment = 5;
        $offset = $this->uri->segment($uri_segment);
        $config['base_url'] = site_url('admin/' . $this->painel_name . '/index/pag');
        $total_registros = $this->conteudo_model->count_all();
        $config['total_rows'] = $total_registros;
        $config['per_page'] = $limit;
        $config['uri_segment'] = $uri_segment;
        $this->pagination->initialize($config);
        $dados_painel['msg'] = $this->session->flashdata('feedback');
        $dados_painel['lista'] = $this->conteudo_model->get_paged_list($limit, $offset)->result();
        $dados_painel['paginacao'] = $this->pagination->create_links();
        $dados_painel['total_registros'] = $total_registros;
        $dados_painel['modo'] = 'default';
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este m�todo exibe o formulário de cadastro da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function insert() {
        $this->load->model('secoes_model');
        $this->load->model('categorias_model');
        $dados_painel['modo'] = 'insert';
        $dados_painel['secoes'] = $this->secoes_model->list_all();
        $dados_painel['categorias'] = $this->categorias_model->list_all();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este m�todo exibe o formulário de alteração da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function update($id = '') {
        $this->load->model('secoes_model');
        $this->load->model('categorias_model');
        if ($id == '')
            redirect('admin/' . $this->painel_name);
        $dados_painel['secoes'] = $this->secoes_model->list_all();
        $dados_painel['categorias'] = $this->categorias_model->list_all();
        $dados_painel['modo'] = 'update';
        $dados_painel['row'] = $this->conteudo_model->get_by_id($id)->row();
        $this->template->load('main_view', $this->painel_name . '_view', $dados_painel);
    }

    /**
     * Este m�todo salva o registro na tabela tb_conteudo.
     * Se houver um ID ele atualiza, caso contrário cria um novo registro.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function save($id = '') {
        $dados_save['cod_categoria'] = $_POST['cod_categoria'];
        $dados_save['cnt_tipo'] = $_POST['cnt_tipo'];
        $dados_save['cnt_link'] = url_title($_POST['cnt_titulo']);
        $dados_save['cnt_titulo'] = $_POST['cnt_titulo'];
        $dados_save['cnt_resumo'] = $_POST['cnt_resumo'];
        $dados_save['cnt_conteudo'] = $_POST['cnt_conteudo'];
        if(isset($_POST['cnt_comentarios']))$dados_save['cnt_comentarios'] = $_POST['cnt_comentarios'];
        if(isset($_POST['cnt_destaque']))$dados_save['cnt_destaque'] = $_POST['cnt_destaque'];
        if(isset($_POST['cnt_publicado']))$dados_save['cnt_publicado'] = $_POST['cnt_publicado'];
        $dados_save['cnt_data_cad'] = mdate('%Y-%m-%d %H:%i:%s', strtotime($_POST['cnt_data_cad']));
        if ($id):
            if ($_POST['alterar_capa']):
                $this->_del_file($id);
                $dados_save['cnt_capa'] = $this->_upload();
            endif;

            if ($this->conteudo_model->update($id, $dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name, 'script');
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados.');
                redirect('admin/' . $this->painel_name, 'script');
            endif;
        else:
            $dados_save['cod_usuario'] = $this->session->userdata('cod_usuario');
            $dados_save['cnt_views'] = 0;
            $dados_save['cnt_capa'] = $this->_upload();
            // Salva o registro
            if ($this->conteudo_model->save($dados_save)):
                $this->session->set_flashdata('feedback', 'Dados salvos com sucesso!');
                redirect('admin/' . $this->painel_name, 'script');
            else:
                $this->session->set_flashdata('feedback', 'Erro ao salvar os dados');
                redirect('admin/' . $this->painel_name, 'script');
            endif;
        endif;
    }

    /**
     * Este m�todo exclui um registro da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function delete($id) {
        $this->_del_file($id);
        if ($this->conteudo_model->delete($id)):
            $this->session->set_flashdata('feedback', 'Dados excluidos com sucesso!');
            redirect('admin/' . $this->painel_name, 'script');
        else:
            $this->session->set_flashdata('feedback', 'Erro ao excluir os dados.');
            redirect('admin/' . $this->painel_name, 'script');
        endif;
    }

    /**
     * Este m�todo faz o upload de uma imagem de capa.
     * 
     * @access private
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return mixed 
     */
    private function _upload() {
        $config['upload_path'] = './midia/capas/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '0';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['remove_spaces'] = TRUE;
        $config['overwrite'] = TRUE;
        $config['file_name'] = md5(date('YmdHis'));
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload()):
            return NULL;
        else:
            $capa = $this->upload->data();
            return $capa['file_name'];
        endif;
    }

    /**
     * Este método verifica se um registro tem imagem cadastrada, em
     * seguida verifica se a imagem existe na pasta de mídia e 
     * se tiver exclui o arquivo físico.
     * 
     * @access private
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $id
     * @return boolean 
     */
    private function _del_file($id) {
        $query = $this->conteudo_model->get_by_id($id)->row();
        $arquivo = $query->cnt_capa;
        if (file_exists('./midia/capas/' . $arquivo)):
            if (unlink('./midia/capas/' . $arquivo)):
                return TRUE;
            else:
                return FALSE;
            endif;
        endif;
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

