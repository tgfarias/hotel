<div id="painel_interno">
    <div id="menu_topo">
        <div class="postmetadataheader">
            <h2 class="postheader">Gerenciador de galerias de mídia.</h2>
        </div>
        <div id="menu">
            <ul>
                <li><?= anchor('admin/midias', 'Galeria de mídia', array('class' => 'ui-button botao')) ?></li>
                <li><?= anchor('admin/itens_midia/insert/' . @$cod_midia, 'Adicionar', array('class' => 'ui-button botao')) ?></li>
                <li><?= anchor('admin/index', 'Fechar', array('class' => 'ui-button botao')) ?></li>
            </ul>
        </div>
    </div>
    <div id="modo">
        <?php
        switch (@$modo):
            default:
                ?>
                <div id="grid">
                    <table border="0" width="100%" align="center" id="grid">
                        <thead>
                            <tr>
                                <th class="ui-widget-header">Código</th>
                                <th class="ui-widget-header">Preview</th>
                                <th class="ui-widget-header">Título</th>
                                <!--th class="ui-widget-header">Tipo</th-->
                                <th class="ui-widget-header">Visualizações</th>
                                <th class="ui-widget-header">Data</th>
                                <th class="ui-widget-header">Publicado</th>
                                <th class="ui-widget-header" width="60"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lista as $row): ?>
                                <tr>
                                    <td valign="middle"><?= $row->cod_item_midia; ?></td>
                                    <td valign="middle">
                                        <?php
                                        if($row->itm_tipo == 'Imagem' OR $row->itm_tipo == 'Massa'):
                                        ?>
                                        <img src="<?=site_url();?>/admin/imagem/thumbs/midia-galerias-<?=$row->itm_pasta?>/<?=$row->itm_file_name; ?>/50/50" />
                                        <?php
                                        else:
                                            echo $row->itm_tipo;
                                        endif;
                                        ?>
                                        
                                    </td>
                                    <td valign="middle"><?= $row->itm_titulo; ?></td>
                                    <!--td valign="middle"><?= $row->itm_tipo; ?></td-->
                                    <td valign="middle"><?= $row->itm_views; ?></td>
                                    <td valign="middle"><?= mdate('%d/%m/%Y', strtotime($row->itm_data_cad)); ?></td>
                                    <td valign="middle"><?= sim_nao($row->itm_publicado); ?></td>
                                    <td valign="middle">
                                        <ul>
                                            <li class="ui-state-default ui-corner-all" title="Alterar">
                                                <?= anchor('admin/itens_midia/update/' . $row->cod_item_midia, 'Alterar', array('class' => 'ui-icon ui-icon-pencil')); ?>
                                            </li>
                                            <li class="ui-state-default ui-corner-all" title="Excluir">
                                                <?= anchor('admin/itens_midia/delete/' . $row->cod_item_midia . '/' . $row->cod_midia, 'Apagar', array('class' => 'ui-icon ui-icon-trash', 'onclick' => 'return apagar()')); ?>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div id="resumo">
                        <span class="total">Total de <b><?= $total_registros; ?></b> registros.</span>
                        <span class="box_paginacao">
                            <?= $paginacao; ?>
                        </span>
                    </div>
                </div>
                <?php
                break;
            case 'insert':
                ?>
                <form name="form_insert" action="<?= site_url('admin/itens_midia/save/'); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                    <input type="hidden" name="MAX_FILE_SIZE" value="9999999999">
                    <input type="hidden" name="cod_midia" value="<?= $cod_midia ?>"/>
                    <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php switch ($tipo_midia):
                                case 'Massa' :
                                    ?>
                                    <tr id="arquivo">
                                        <td>Arquivos Massa</td>
                                        <td><input type="file" multiple="multiple" id="fotos" name="fotos[]" size="45"/> Formatos suportados: gif, jpg, png</td>
                                    </tr>
                                    <?php 
                                    break;
                                case 'Youtube' :
                                    ?>
                                    <tr id="titulo">
                                        <td>Título</td>
                                        <td><input type="text" name="itm_titulo" size="100"/></td>
                                    </tr>
                                    <tr id="descricao">
                                        <td></td>
                                        <td>
                                            <p><b>Descrição</b></p>
                                            <textarea name="itm_descricao" cols="45" rows="8"></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <p><b>Código do Youtube</b></p>
                                            <input type="text" name="itm_conteudo" size="25"/> Colocar somente o código destacado no exemplo: http://www.youtube.com/embed/<b><font color="#ff0000">Myb0yUHdi14</font></b>
                                            <!-- <textarea name="itm_conteudo" cols="45" rows="9"></textarea></td> -->
                                    </tr>
                                    <?php 
                                    break;
                                default :
                                ?>
                                    <tr id="titulo">
                                        <td>Título</td>
                                        <td><input type="text" name="itm_titulo" size="100"/></td>
                                    </tr>
                                    <tr id="descricao">
                                        <td></td>
                                        <td>
                                            <p><b>Descrição</b></p>
                                            <textarea name="itm_descricao" cols="45" rows="8"></textarea>
                                        </td>
                                    </tr>
                                    <tr id="arquivo">
                                        <td>Arquivo individual</td>
                                        <td><input type="file" id="userfile" name="userfile" size="45"/> Formatos suportados: gif, jpg, png, mp3, rar, zip, pdf, tar, tar.gz</td>
                                    </tr>
                            <?php break;
                                endswitch;
                            ?>

                            <tr>
                                <td>Data</td>
                                <td><input class="data" type="text" name="itm_data_cad" size="15"/></td>
                            </tr>
                            <tr>
                                <td>Publicado</td>
                                <td><label><input type="checkbox" name="itm_publicado" value="1" /> Publicado</label></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                    <?= anchor('admin/itens_midia/index/' . $cod_midia, 'Cancelar'); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
        <?php
        break;
            case 'update':
                ?>
                <form name="form_update" action="<?= site_url('admin/itens_midia/save/' . $row->cod_item_midia); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                    <input type="hidden" name="cod_midia" value="<?= $row->cod_midia; ?>"/>
                    <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                        <thead>
                            <tr>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Título</td>
                                <td><input type="text" name="itm_titulo" value="<?= $row->itm_titulo; ?>" size="100"/></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <p>Descrição</p>
                                    <textarea name="itm_descricao" cols="100" rows="8"><?= $row->itm_descricao; ?></textarea>
                                </td>
                            </tr>

<!-- xxxx -->

							<?php switch ($row->itm_tipo):
                                case 'Massa' :
                                    ?>
                                    <tr id="arquivo">
                                        <td>Arquivos Massa</td>
                                        <td><input type="file" multiple="multiple" id="fotos" name="fotos[]" size="45"/> Formatos suportados: gif, jpg, png</td>
                                    </tr>
                                    <?php 
                                    break;
                                case 'Youtube' :
                                    ?>
                                    <!--tr id="titulo">
                                        <td>Título</td>
                                        <td><input type="text" name="itm_titulo" value="<?= $row->itm_titulo; ?>" size="100"/></td>
                                    </tr-->
                                    <!-- <tr id="descricao">
                                        <td></td>
                                        <td>
                                            <p><b>Descrição</b></p>
                                            <textarea name="itm_descricao" cols="45" rows="8"><?= $row->itm_descricao; ?></textarea>
                                        </td>
                                    </tr> -->
                                    <tr>
                                        <td></td>
                                        <td>
                                            <p><b>Código HTML do Youtube</b></p>
                                            <input type="text" name="itm_conteudo" value="<?= $row->itm_conteudo; ?>" size="25"/> Colocar somente o código destacado no exemplo: http://www.youtube.com/embed/<b><font color="#ff0000">Myb0yUHdi14</font></b>
                                            <!-- <textarea name="itm_conteudo" cols="45" rows="9"><?= $row->itm_conteudo; ?></textarea> -->
                                        </td>
                                    </tr>
                                    <?php 
                                    break;
                                default :
                                ?>
                                    <!--tr id="titulo">
                                        <td>Título</td>
                                        <td><input type="text" name="itm_titulo" size="100"/></td>
                                    </tr-->
                                    <tr id="descricao">
                                        <td></td>
                                        <td>
                                            <p><b>Descrição</b></p>
                                            <textarea name="itm_descricao" cols="45" rows="8"><?= $row->itm_descricao; ?></textarea>
                                        </td>
                                    </tr>
                                    <tr id="arquivo">
                                        <td>Arquivo individual</td>
                                        <td>
											<p><input type="file" id="userfile" name="userfile" size="45"/> Formatos suportados: gif, jpg, png, mp3, rar, zip, pdf, tar, tar.gz</p>
											<p><label><input type="checkbox" name="alterar_arquivo" value="1" /> Alterar o arquivo</label></p>
											<p><img src="<?=site_url();?>/admin/imagem/thumbs/midia-galerias-<?=$row->itm_pasta?>/<?=$row->itm_file_name; ?>/300/300" /></p>
										</td>
                                    </tr>
                            <?php break;
                                endswitch;
                            ?>
<!-- xxxx -->
                            <!--tr id="arquivo">
                                <td>Arquivo</td>
                                <td>
                                    <p><input type="file" name="userfile" value="<?= $row->itm_file_name; ?>" size="45"/> <label><input type="checkbox" name="alterar_arquivo" value="1" /> Alterar o arquivo</label></p>
                                    <?php if($row->itm_file_name): ?>
                                    <p><b>Preview</b></p>
                                    <p>
                                        <img src="<?=site_url();?>/admin/imagem/thumbs/midia-galerias-<?=$row->itm_pasta?>/<?=$row->itm_file_name; ?>/300/300" />
                                        <!--img src="<?= base_url('midia/galerias/' . $row->itm_pasta . '/' . $row->itm_file_name); ?>" width="300"/-->
                                    <!--/p>
                                    <?php endif; ?>
                                </td>
                            </tr-->
                            <!--tr id="html">
                                <td></td>
                                <td>
                                    <p>Código HTML do Youtube</p>
                                    <textarea name="itm_conteudo" cols="100" rows="9"><?= $row->itm_conteudo; ?></textarea>
                                </td>
                            </tr-->
                            <tr>
                                <td>Visualizações</td>
                                <td><input type="text" name="itm_views" value="<?= $row->itm_views; ?>" size="5"/></td>
                            </tr>
                            <tr>
                                <td>Data</td>
                                <td><input class="data" type="text" name="itm_data_cad" value="<?= mdate('%d/%m/%Y', strtotime($row->itm_data_cad)); ?>" size="15"/></td>
                            </tr>
                            <tr>
                                <td>Publicado</td>
                                <td><label><input type="checkbox" name="itm_publicado" value="1" <?= marcado($row->itm_publicado); ?>/> Publicado</label></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                    <?= anchor('admin/itens_midia/index/' . $row->cod_midia, 'Cancelar'); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
                <?php
            endswitch;
            ?>
    </div>
</div>