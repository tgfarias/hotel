<div id="painel_interno">
    <div id="menu_topo">
        <div class="postmetadataheader">
            <h2 class="postheader">Gerenciador de veiculos.</h2>
        </div>
        <div id="menu">
            <ul>
                <li><?= anchor('admin/veiculos/insert', 'Adicionar', array('class' => 'ui-button botao')) ?></li>
                <li><?= anchor('admin/index', 'Fechar', array('class' => 'ui-button botao')) ?></li>
            </ul>
        </div>
    </div>
    <div id="modo">
    <?php
        switch (@$modo):
        default:
            ?>
            <div id="grid">
                <table border="0" width="100%" align="center" id="grid">
                    <thead>
                        <tr>
                            <th class="ui-widget-header">Cod</th>
                            <th class="ui-widget-header">Veículo</th>
                            <th class="ui-widget-header">Cor</th>
                            <th class="ui-widget-header">Ano</th>
                            <th class="ui-widget-header">Data de cadastro</th>
                            <th class="ui-widget-header">Ativo</th>
                            <th class="ui-widget-header">Destaque</th>
                            <th class="ui-widget-header" width="60"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $row): ?>
                            <tr>
                                <td valign="middle"><?= $row->cod_veiculo; ?></td>
                                <td valign="middle"><?= $row->nome; ?></td>
                                <td valign="middle"><?= $row->cor; ?></td>
                                <td valign="middle"><?= $row->ano_fab; ?></td>
                                <td valign="middle"><?= mdate('%d/%m/%Y', strtotime($row->data_cadastro)); ?></td>
                                <td valign="middle"><?= sim_nao($row->ativo); ?></td>
                                <td valign="middle"><?= sim_nao($row->destaque); ?></td>
                                <td valign="middle">
                                    <ul>
                                        <li class="ui-state-default ui-corner-all" title="Alterar">
                                            <?= anchor('admin/veiculos/update/' . $row->cod_veiculo, 'Alterar', array('class' => 'ui-icon ui-icon-pencil')); ?>
                                        </li>
                                        <li class="ui-state-default ui-corner-all" title="Excluir">
                                            <?= anchor('admin/veiculos/delete/' . $row->cod_veiculo, 'Apagar', array('class' => 'ui-icon ui-icon-trash', 'onclick' => 'return apagar()')); ?>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div id="resumo">
                    <span class="total">Total de <b><?= $total_registros; ?></b> registros.</span>
                    <span class="box_paginacao">
                        <?= $paginacao; ?>
                    </span>
                </div>
            </div>
            <?php
            break;
        case 'insert':
            ?>
            <form name="form_insert" action="<?= site_url('admin/veiculos/save/'); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Tipo</td>
                             <td>
                                <select name="cod_tipo_veiculo" class="form_input">
                                <?php foreach(relacionamento('tipo_veiculo', 'cod_tipo_veiculo', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_tipo_veiculo;?>"><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Marca</td>
                             <td>
                                <select name="cod_marca" class="form_input">
                                <?php foreach(relacionamento('marcas', 'cod_marca', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_marca;?>"><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Cidade</td>
                             <td>
                                <select name="cod_cidade" class="form_input">
                                <?php foreach(relacionamento('cidades', 'cod_cidade', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_cidade;?>"><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Veículo</td>
                             <td><input type="text" name="nome" size="65" class="form_input" /></td>
                         </tr>
<!--                         <tr>
                             <td>Cor</td>
                             <td><input type="text" name="cor" size="45" class="form_input" /></td>
                         </tr>-->
                         <tr>
                             <td>Ano de fabricação</td>
                             <td><input type="text" name="ano_fab" size="10" class="form_input" /> Ano do modelo <input type="text" name="ano_mod" size="10" class="form_input" /> Cor <input type="text" name="cor" size="15" class="form_input" /></td>
                         </tr>
<!--                         <tr>
                             <td>Ano do modelo</td>
                             <td><input type="text" name="ano_mod" size="45" class="form_input" /></td>
                         </tr>-->
                         <tr>
                             <td>Motorização</td>
                             <td>
                                 <input type="text" name="motor" size="10" class="form_input" /> 
                                 Combustível 
                                 <!--<input type="text" name="combustivel" size="45" class="form_input" />-->
                                 <select name="combustivel" class="form_input">
                                     <option value="Gasolina">Gasolina</option>
                                     <option value="Etanol">Etanol</option>
                                     <option value="Flex">Flex</option>
                                     <option value="Diesel">Diesel</option>
                                 </select>
                             </td>
                         </tr>
<!--                         <tr>
                             <td>Combustível</td>
                             <td><input type="text" name="combustivel" size="45" class="form_input" /></td>
                         </tr>-->
                         <tr>
                             <td></td>
                             <td><b>Acessórios</b></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="arcond" value="1" /> Ar condicionado</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="alarme" value="1" /> Alarme</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="direcao" value="1" /> Direção hidráulica</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="vidro" value="1" /> Vidro elétrico</label></td>
                         </tr>
                         <tr>
                             <td>Observações</td>
                             <td><textarea name="observacoes" rows="9" cols="60" class="form_input"></textarea></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><b>Fotos</b></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>Você pode carregar todas as fotos de uma vez, até o máximo de 10 fotos por veículo.</td>
                         </tr>
                         <tr id="arquivo">
                             <td></td>
                             <td><input type="file" multiple="multiple" id="fotos" name="fotos[]" size="45"/> Formatos suportados: gif, jpg, png</td>
                         </tr>
                         <tr>
                             <td>Data de cadastro</td>
                             <td><input type="text" name="data_cadastro" size="15" class="data" /></td>
                         </tr>
                         <tr>
                             <td>Valor</td>
                             <td><input type="text" name="valor" size="15" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="ativo" value="1" /> Veículo ativo</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="destaque" value="1" /> Anúncio em destaque</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/veiculos', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
             <?php
             break;
         case 'update':
             ?>
             <form name="form_update" action="<?= site_url('admin/veiculos/save/' . $row->cod_veiculo); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                 <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                     <thead>
                         <tr>
                             <th></th>
                             <th></th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Tipo</td>
                             <td>
                                <select name="cod_tipo_veiculo" class="form_input">
                                <?php foreach(relacionamento('tipo_veiculo', 'cod_tipo_veiculo', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_tipo_veiculo;?>" <?php if($row->cod_tipo_veiculo == $rel->cod_tipo_veiculo)echo 'selected'; ?>><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Marca</td>
                             <td>
                                <select name="cod_marca" class="form_input">
                                <?php foreach(relacionamento('marcas', 'cod_marca', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_marca;?>" <?php if($row->cod_marca == $rel->cod_marca)echo 'selected'; ?>><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Cidade</td>
                             <td>
                                <select name="cod_cidade" class="form_input">
                                <?php foreach(relacionamento('cidades', 'cod_cidade', 'titulo', '', 'form') as $rel): ?>
                                    <option value="<?=$rel->cod_cidade;?>" <?php if($row->cod_cidade == $rel->cod_cidade)echo 'selected'; ?>><?=$rel->titulo;?></option>
                                <?php endforeach; ?>
                                </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Veículo</td>
                             <td><input type="text" name="nome" value="<?= $row->nome; ?>" size="65" class="form_input" /></td>
                         <tr>
                             <td>Ano de fabricação</td>
                             <td>
                                 <input type="text" name="ano_fab" value="<?= $row->ano_fab; ?>" size="10" class="form_input" />
                                 Ano do modelo
                                 <input type="text" name="ano_mod" value="<?= $row->ano_mod; ?>" size="10" class="form_input" />
                                 Cor
                                 <input type="text" name="cor" value="<?= $row->cor; ?>" size="15" class="form_input" />
                             </td>
                         </tr>
                         <tr>
                             <td></td>
                             <td></td>
                         </tr>
                         <tr>
                             <td>Motorização</td>
                             <td>
                                 <input type="text" name="motor" value="<?= $row->motor; ?>" size="10" class="form_input" />
                                 Combustível
                                 <select name="combustivel" class="form_input">
                                     <option value="Gasolina" <?php if($row->combustivel == 'Gasolina'){ echo 'selected';} ?>>Gasolina</option>
                                     <option value="Etanol" <?php if($row->combustivel == 'Etanol'){ echo 'selected';} ?>>Etanol</option>
                                     <option value="Flex" <?php if($row->combustivel == 'Flex'){ echo 'selected';} ?>>Flex</option>
                                     <option value="Diesel" <?php if($row->combustivel == 'Diesel'){ echo 'selected';} ?>>Diesel</option>
                                 </select>
                             </td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="arcond" value="1" <?= marcado($row->arcond); ?> /> Ar condicionado</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="alarme" value="1" <?= marcado($row->alarme); ?> /> Aalrme</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="direcao" value="1" <?= marcado($row->direcao); ?> /> Direção hidráulica</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="vidro" value="1" <?= marcado($row->vidro); ?> /> Vidro elétrico</label></td>
                         </tr>
                         <tr>
                             <td>Observações</td>
                             <td><textarea name="observacoes" rows="9" cols="60" class="form_input"><?= $row->observacoes; ?></textarea></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <p><b>Fotos</b></p>
                                 <?php
                                 $arrFotos = listaFotosVeiculo($row->cod_veiculo);
                                 ?>
                                 <table>
                                     <tr>
                                         <?php foreach($arrFotos as $foto){ ?>
                                         <td>
                                             <p><img src="<?= base_url('midia/veiculos/'.$foto['pasta']).'/'.$foto['foto']; ?>" width="75" /></p>
                                             <p><?= anchor('admin/fotos_veiculo/update/'.$foto['cod_foto_veiculo'], 'Alt'); ?> | <?= anchor('admin/fotos_veiculo/delete/'.$foto['cod_foto_veiculo'], 'Del', array('onclick' => 'return apagar()')); ?></p>
                                         </td>
                                         <?php } ?>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><?= anchor('admin/fotos_veiculo/insert/'.$row->cod_veiculo, 'Inserir nova foto'); ?></td>
                         </tr>
                         <tr>
                             <td>Data de cadastro</td>
                             <td><input type="text" name="data_cadastro" value="<?= mdate('%d/%m/%Y', strtotime($row->data_cadastro)); ?>" size="20" class="data" /></td>
                         </tr>
                         <tr>
                             <td>Valor</td>
                             <td><input type="text" name="valor" value="<?= $row->valor; ?>" size="15" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="ativo" value="1" <?= marcado($row->ativo); ?> /> Ativo</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="destaque" value="1" <?= marcado($row->destaque); ?> /> Anúncio em destaque</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/veiculos', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
            <?php
        endswitch;
        ?>
    </div>
</div>
