<div id="painel_interno">
    <div id="menu_topo">
        <div class="postmetadataheader">
            <h2 class="postheader">Gerenciador de newsletters.</h2>
        </div>
        <div id="menu">
            <ul>
                <li><?= anchor('admin/newsletters/insert', 'Adicionar', array('class' => 'ui-button botao')) ?></li>
                <li><?= anchor('admin/index', 'Fechar', array('class' => 'ui-button botao')) ?></li>
            </ul>
        </div>
    </div>
    <div id="modo">
    <?php
        switch (@$modo):
        default:
            ?>
            <div id="grid">
                <table border="0" width="100%" align="center" id="grid">
                    <thead>
                        <tr>
                            <th class="ui-widget-header">Cod</th>
                            <th class="ui-widget-header">Nome</th>
                            <th class="ui-widget-header">Email</th>
                            <th class="ui-widget-header">Ativo</th>
                            <th class="ui-widget-header">Data</th>
                            <th class="ui-widget-header" width="60"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $row): ?>
                            <tr>
                                <td valign="middle"><?= $row->cod_newsletter; ?></td>
                                <td valign="middle"><?= $row->new_nome; ?></td>
                                <td valign="middle"><?= $row->new_email; ?></td>
                                <td valign="middle"><?= $row->new_ativo; ?></td>
                                <td valign="middle"><?= mdate('%d/%m/%Y', strtotime($row->new_data_cad)); ?></td>
                                <td valign="middle">
                                    <ul>
                                        <li class="ui-state-default ui-corner-all" title="Alterar">
                                            <?= anchor('admin/newsletters/update/' . $row->cod_newsletter, 'Alterar', array('class' => 'ui-icon ui-icon-pencil')); ?>
                                        </li>
                                        <li class="ui-state-default ui-corner-all" title="Excluir">
                                            <?= anchor('admin/newsletters/delete/' . $row->cod_newsletter, 'Apagar', array('class' => 'ui-icon ui-icon-trash', 'onclick' => 'return apagar()')); ?>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div id="resumo">
                    <span class="total">Total de <b><?= $total_registros; ?></b> registros.</span>
                    <span class="box_paginacao">
                        <?= $paginacao; ?>
                    </span>
                </div>
            </div>
            <?php
            break;
        case 'insert':
            ?>
            <form name="form_insert" action="<?= site_url('admin/newsletters/save/'); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Nome</td>
                             <td><input type="text" name="new_nome" size="45" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td>Email</td>
                             <td><input type="text" name="new_email" size="45" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td>Ativo</td>
                             <td><input type="checkbox" name="new_ativo" value="1" /></td>
                         </tr>
                         <tr>
                             <td>Data</td>
                             <td><input type="text" name="new_data_cad" size="20" class="data" /></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/newsletters', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
             <?php
             break;
         case 'update':
             ?>
             <form name="form_update" action="<?= site_url('admin/newsletters/save/' . $row->cod_newsletter); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                 <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                     <thead>
                         <tr>
                             <th></th>
                             <th></th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Nome</td>
                             <td><input type="text" name="new_nome" value="<?= $row->new_nome; ?>" size="45" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td>Email</td>
                             <td><input type="text" name="new_email" value="<?= $row->new_email; ?>" size="45" class="form_input" /></td>
                         </tr>
                         <tr>
                             <td>Ativo</td>
                             <td><input type="checkbox" name="new_ativo" value="1" <?= marcado($row->new_ativo); ?> /></td>
                         </tr>
                         <tr>
                             <td>Data</td>
                             <td><input type="text" name="new_data_cad" value="<?= mdate('%d/%m/%Y', strtotime($row->new_data_cad)); ?>" size="20" class="data" /></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/newsletters', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
            <?php
        endswitch;
        ?>
    </div>
</div>
