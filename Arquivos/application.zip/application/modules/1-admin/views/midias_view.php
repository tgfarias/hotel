<div id="painel_interno">
    <div id="menu_topo">
        <div class="postmetadataheader">
            <h2 class="postheader">Gerenciador de galerias de mídia.</h2>
        </div>
        <div id="menu">
            <ul>
                <li><?= anchor('admin/midias/insert', 'Adicionar', array('class' => 'ui-button botao')) ?></li>
                <li><?= anchor('admin/index', 'Fechar', array('class' => 'ui-button botao')) ?></li>
            </ul>
        </div>
    </div>
    <div id="modo">
    <?php
        switch (@$modo):
        default:
            ?>
            <div id="grid">
                <table border="0" width="100%" align="center" id="grid">
                    <thead>
                        <tr>
                            <th class="ui-widget-header">Código</th>
                            <th class="ui-widget-header">Capa</th>
                            <th class="ui-widget-header">Título</th>
                            <th class="ui-widget-header">Data</th>
                            <th class="ui-widget-header">É destaque</th>
                            <th class="ui-widget-header">Aceita comentários</th>
                            <th class="ui-widget-header">Publicado</th>
                            <th class="ui-widget-header" width="60"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $row): ?>
                            <tr>
                                <td valign="middle"><?= $row->cod_midia; ?></td>
                                <td valign="middle"><img src="<?=site_url();?>/admin/imagem/thumbs/midia-capas/<?=$row->mid_capa; ?>/50/50" /></td>
                                <td valign="middle"><?= anchor('admin/itens_midia/index/'.$row->cod_midia,$row->mid_titulo); ?></td>
                                <td valign="middle"><?= mdate('%d/%m/%Y', strtotime($row->mid_data_cad)); ?></td>
                                <td valign="middle"><?= sim_nao($row->mid_destaque); ?></td>
                                <td valign="middle"><?= sim_nao($row->mid_comentario); ?></td>
                                <td valign="middle"><?= sim_nao($row->mid_publicado); ?></td>
                                <td valign="middle">
                                    <ul>
                                        <li class="ui-state-default ui-corner-all" title="Alterar">
                                            <?= anchor('admin/midias/update/' . $row->cod_midia, 'Alterar', array('class' => 'ui-icon ui-icon-pencil')); ?>
                                        </li>
                                        <li class="ui-state-default ui-corner-all" title="Excluir">
                                            <?= anchor('admin/midias/delete/' . $row->cod_midia, 'Apagar', array('class' => 'ui-icon ui-icon-trash', 'onclick' => 'return apagar()')); ?>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div id="resumo">
                    <span class="total">Total de <b><?= $total_registros; ?></b> registros.</span>
                    <span class="box_paginacao">
                        <?= $paginacao; ?>
                    </span>
                </div>
            </div>
            <?php
            break;
        case 'insert':
            ?>
            <form name="form_insert" action="<?= site_url('admin/midias/save/'); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Título</td>
                             <td><input type="text" name="mid_titulo" size="100"/></td>
                         </tr>
                         <tr>
                             <td>Tipo</td>
                             <td>
                                 <select name="mid_tipo">
                                     <option value="Imagem">Imagem</option>
                                     <option value="Massa">Imagem em massa</option>
                                     <option value="Youtube">Vídeo (Youtube)</option>
                                     <option value="Audio">Audio</option>
                                     <option value="Arquivo">Arquivo</option>
                                 </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Capa</td>
                             <td><input type="file" name="userfile" size="45"/></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <p><b>Descrição</b></p>
                                 <textarea name="mid_descricao" cols="45" rows="9"></textarea>
                             </td>
                         </tr>
                         <tr>
                             <td>Data</td>
                             <td><input type="text" name="mid_data_cad" class="data" size="20"/> dd/mm/aaaa</td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_destaque" value="1" /> É destaque</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_comentario" value="1" /> Aceita comentários</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_publicado" value="1" /> Publicado</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/midias', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
             <?php
             break;
         case 'update':
             ?>
             <form name="form_update" action="<?= site_url('admin/midias/save/' . $row->cod_midia); ?>" method="POST" enctype="multipart/form-data" class="ui-widget-content">
                 <input type="hidden" name="mid_tipo" value="Massa"/>
                 <table border="0" width="100%" align="center" class="ui-widget" id="table_form">
                     <thead>
                         <tr>
                             <th></th>
                             <th></th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr>
                             <td>Título</td>
                             <td><input type="text" name="mid_titulo" value="<?= $row->mid_titulo; ?>" size="100"/></td>
                         </tr>
						<tr>
                             <td>Tipo</td>
                             <td>
                                 <select name="mid_tipo">
                                     <option value="Imagem" <?php if($row->mid_tipo == 'Imagem'){ echo 'selected'; } ?> >Imagem</option>
                                     <option value="Massa" <?php if($row->mid_tipo == 'Massa'){ echo 'selected'; } ?> >Imagem em massa</option>
                                     <option value="Youtube" <?php if($row->mid_tipo == 'Youtube'){ echo 'selected'; } ?> >Vídeo (Youtube)</option>
                                     <option value="Audio" <?php if($row->mid_tipo == 'Audio'){ echo 'selected'; } ?> >Audio</option>
                                     <option value="Arquivo" <?php if($row->mid_tipo == 'Arquivo'){ echo 'selected'; } ?> >Arquivo</option>
                                 </select>
                             </td>
                         </tr>
                         <tr>
                             <td>Capa</td>
                             <td><input type="file" name="userfile" size="45"/> <label><input type="checkbox" name="alterar_capa" value="1" /> Alterar a imagem de capa.</label></td>
                         </tr>
						<tr>
                             <td></td>
                             <td>
                             	<p><b>Pré-visualização</b></p>
								<img src="<?=site_url();?>/admin/imagem/thumbs/midia-capas/<?=$row->mid_capa; ?>/100/100" />
                             </td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <p><b>Descrição</b></p>
                                 <textarea name="mid_descricao" cols="45" rows="9"><?= $row->mid_descricao; ?></textarea>
                             </td>
                         </tr>
                         <tr>
                             <td>Data</td>
                             <td><input type="text" name="mid_data_cad" class="data" value="<?= mdate('%d/%m/%Y', strtotime($row->mid_data_cad)); ?>" size="15"/></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_destaque" <?= marcado($row->mid_destaque); ?> value="1" /> É destaque</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_comentario" <?= marcado($row->mid_comentario); ?> value="1" /> Aceita comentários</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td><label><input type="checkbox" name="mid_publicado" <?= marcado($row->mid_publicado); ?> value="1" /> Publicado</label></td>
                         </tr>
                         <tr>
                             <td></td>
                             <td>
                                 <input type="submit" value="Salvar" name="bot_salvar" class="ui-button botao" />
                                 <?= anchor('admin/midias', 'Cancelar'); ?>
                             </td>
                         </tr>
                     </tbody>
                 </table>
             </form>
            <?php
        endswitch;
        ?>
    </div>
</div>
