<?php

if (!function_exists('listaEstoque')) {
    
    function listaEstoque(){
        
        $CI = & get_instance();
        $CI->load->model('veiculos_model');
        
        $query = $CI->veiculos_model->lista_estoque();
        $i = 0;
        
        $saida = array();
        $temp = array();
        
        foreach ($query->result() as $row):
            $temp['cod_veiculo'] = $row->cod_veiculo;
            $temp['cod_usuario'] = $row->cod_usuario;
            $temp['cod_tipo_veiculo'] = $row->cod_tipo_veiculo;
            $temp['cod-marca'] = $row->cod_marca;
            $temp['cod_cidade'] = $row->cod_cidade;
            $temp['nome'] = $row->nome;
            $temp['cor'] = $row->cor;
            $temp['ano_fab'] = $row->ano_fab;
            $temp['ano_mod'] = $row->ano_mod;
            $temp['motor'] = $row->motor;
            $temp['combustivel'] = $row->combustivel;
            $temp['arcond'] = $row->arcond;
            $temp['alarme'] = $row->alarme;
            $temp['direcao'] = $row->direcao;
            $temp['vidro'] = $row->vidro;
            $temp['observacoes'] = $row->observacoes;
            $temp['data_cadastro'] = $row->data_cadastro;
            $temp['valor'] = $row->valor;
            $temp['destaque'] = $row->destaque;
            $temp['ativo'] = $row->ativo;
            $temp['fotos'] = listaFotosVeiculo($row->cod_veiculo);
            array_push($saida, $temp);
        endforeach;
        
        return $saida;
        
    }
}

if (!function_exists('listaVeiculosDestaque')) {
    
    function listaVeiculosDestaque(){
        
        $CI = & get_instance();
        $CI->load->model('veiculos_model');
        
        $query = $CI->veiculos_model->get_all_destaque();
        $i = 0;
        
        $saida = array();
        $temp = array();
        
        foreach ($query->result() as $row):
            $temp['cod_veiculo'] = $row->cod_veiculo;
            $temp['cod_usuario'] = $row->cod_usuario;
            $temp['cod_tipo_veiculo'] = $row->cod_tipo_veiculo;
            $temp['cod-marca'] = $row->cod_marca;
            $temp['cod_cidade'] = $row->cod_cidade;
            $temp['nome'] = $row->nome;
            $temp['cor'] = $row->cor;
            $temp['ano_fab'] = $row->ano_fab;
            $temp['ano_mod'] = $row->ano_mod;
            $temp['motor'] = $row->motor;
            $temp['combustivel'] = $row->combustivel;
            $temp['arcond'] = $row->arcond;
            $temp['alarme'] = $row->alarme;
            $temp['direcao'] = $row->direcao;
            $temp['vidro'] = $row->vidro;
            $temp['observacoes'] = $row->observacoes;
            $temp['data_cadastro'] = $row->data_cadastro;
            $temp['valor'] = $row->valor;
            $temp['destaque'] = $row->destaque;
            $temp['ativo'] = $row->ativo;
            $temp['fotos'] = listaFotosVeiculo($row->cod_veiculo);
            array_push($saida, $temp);
        endforeach;
        
        return $saida;
        
    }
}

if (!function_exists('detalheVeiculo')) {
    
    function detalheVeiculo($cod_veiculo){
        
        $CI = & get_instance();
        $CI->load->model('veiculos_model');
        
        $query = $CI->veiculos_model->get_by_id($cod_veiculo)->row();
        $i = 0;
        
        $saida = array();
        
        $saida['cod_veiculo'] = $query->cod_veiculo;
        $saida['cod_usuario'] = $query->cod_usuario;
        $saida['cod_tipo_veiculo'] = $query->cod_tipo_veiculo;
        $saida['cod_marca'] = $query->cod_marca;
        $saida['cod_cidade'] = $query->cod_cidade;
        $saida['nome'] = $query->nome;
        $saida['cor'] = $query->cor;
        $saida['ano_fab'] = $query->ano_fab;
        $saida['ano_mod'] = $query->ano_mod;
        $saida['motor'] = $query->motor;
        $saida['combustivel'] = $query->combustivel;
        $saida['arcond'] = $query->arcond;
        $saida['alarme'] = $query->alarme;
        $saida['direcao'] = $query->direcao;
        $saida['vidro'] = $query->vidro;
        $saida['observacoes'] = $query->observacoes;
        $saida['data_cadastro'] = $query->data_cadastro;
        $saida['valor'] = $query->valor;
        $saida['destaque'] = $query->destaque;
        $saida['ativo'] = $query->ativo;
        $saida['fotos'] = listaFotosVeiculo($query->cod_veiculo);
        
        return $saida;
        
    }
}

if (!function_exists('listaFotosVeiculo')) {
    
    function listaFotosVeiculo($cod_veiculo){
        
        $CI = & get_instance();
        $CI->load->model('fotos_veiculo_model');
        
        $query = $CI->fotos_veiculo_model->get_by_veiculo($cod_veiculo);
        $i = 0;
        
        $saida = array();
        $temp = array();
        
        foreach ($query->result() as $row):
            $temp['cod_foto_veiculo'] = $row->cod_foto_veiculo;
            $temp['cod_veiculo'] = $row->cod_veiculo;
            $temp['pasta'] = $row->pasta;
            $temp['foto'] = $row->foto;
            array_push($saida, $temp);
        endforeach;
        
        return $saida;
    }
}

if (!function_exists('listaAnoFab')) {
    
    function listaAnoFab(){
        $CI = & get_instance();
        $CI->load->model('veiculos_model');
        $query = $CI->veiculos_model->lista_ano_fabricacao();
        $saida = array();
        $temp = array();
        foreach($query->result() as $row){
            $temp['ano_fab'] = $row->ano_fab;
            array_push($saida, $temp);
        }
        return $saida;
    }
}

if (!function_exists('listaAnoMod')) {
    
    function listaAnoMod(){
        $CI = & get_instance();
        $CI->load->model('veiculos_model');
        $query = $CI->veiculos_model->lista_ano_modelo();
        $saida = array();
        $temp = array();
        foreach($query->result() as $row){
            $temp['ano_mod'] = $row->ano_mod;
            array_push($saida, $temp);
        }
        return $saida;
    }
}

if (!function_exists('listaEstados')) {
    
    function listaEstados(){
        $CI = & get_instance();
        $CI->load->model('estados_model');
        $query = $CI->estados_model->list_all();
        $saida = array();
        $temp = array();
        foreach($query->result() as $row){
            $temp['cod_estado'] = $row->cod_estado;
            $temp['titulo'] = $row->titulo;
            array_push($saida, $temp);
        }
        return $saida;
    }
}