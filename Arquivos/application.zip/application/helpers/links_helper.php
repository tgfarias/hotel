<?php

if (!function_exists('listaLinks')) {
    
    function listaLinks(){
        $CI = & get_instance();
        $CI->load->model('links_model');
        $query = $CI->links_model->list_all();
        $i = 0;
        $saida = array();
        $temp = array();
        foreach ($query->result() as $row):
            $temp['cod_link'] = $row->cod_link;
            $temp['titulo'] = $row->titulo;
            $temp['link'] = $row->link;
            array_push($saida, $temp);
        endforeach;
        return $saida;
    }
}