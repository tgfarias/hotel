<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o gerenciamento da tabela tb_itens_midia 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */
class itens_midia_model extends CI_Model {

    private $tabela = 'tb_itens_midia';
    private $primary_key = 'cod_item_midia';

    function __construct() {
        parent::__construct();
    }
    
    public function get_ultimas_midias($tipo = 'Imagem', $inicio = NULL, $fim = NULL){
        
        switch ($tipo):
            case 'Imagem':
                $this->db->where('itm_tipo', 'Imagem');
                $this->db->or_where('itm_tipo', 'Massa');
                break;
            case 'Video':
                $this->db->where('itm_tipo', 'Youtube');
                break;
            case 'Audio':
                $this->db->where('itm_tipo', 'Audio');
                break;
            case 'Arquivo':
                $this->db->where('itm_tipo', 'Arquivo');
                break;
        endswitch;
        
        $this->db->order_by('itm_data_cad', 'desc');
        $this->db->order_by('itm_publicado', '1');
        if($inicio)$this->db->limit($inicio, $fim);
        
        return $this->db->get($this->tabela);
        
    }

    /**
     * Este método retorna uma lista de itens de acordo com o código 
     * da galeria indicado no parãmetro, os resultados são somente os
     * itens marcados como publicado e ordenados por dara de cadastro.
     * 
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @access public
     * @param int $cod_midia
     * @return mixed
     */
    public function lista_itens($cod_midia) {
        $this->db->where('itm_publicado', '1');
        
        if(isset($cod_midia))$this->db->where('cod_midia', $cod_midia);
        
        $this->db->order_by('itm_data_cad');
        return $this->db->get($this->tabela);
    }

    /**
     * Este método lista todos os resultados da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function list_all($cod_midia) {
        // Aqui pode-se fazer um filtro e passar os parametros pelo metodo.
        if ($cod_midia)
            $this->db->where('cod_midia', $cod_midia);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método faz a contagem de todos os registros da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function count_all($cod_midia) {
        $query = $this->db->query('SELECT COUNT(cod_midia) AS Total FROM tb_itens_midia WHERE cod_midia = "' . $cod_midia . '"')->row();
        return $query->Total;
    }

    /**
     * Este método recupera uma consulta com paginação da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function get_paged_list($cod_midia, $limit = 10, $offset = 0) {
        $this->db->where('cod_midia', $cod_midia);
        $this->db->order_by($this->primary_key, 'asc');
        return $this->db->get($this->tabela, $limit, $offset);
    }

    /**
     * Este método recupera um registro da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function get_by_id($id) {
        $this->db->where($this->primary_key, $id);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método salva um registro na tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function save($dados) {
        $this->db->insert($this->tabela, $dados);
        return $this->db->insert_id();
    }

    /**
     * Este método atualiza um registro na tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function update($id, $dados) {
        $this->db->where($this->primary_key, $id);
        $this->db->update($this->tabela, $dados);
        return $this->db->affected_rows();
    }

    /**
     * Este método exclui um registro da tabela tb_itens_midia.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function delete($id) {
        $this->db->where($this->primary_key, $id);
        $this->db->delete($this->tabela);
        return $this->db->affected_rows();
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

