<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o gerenciamento da tabela tb_midias 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */

class midias_model extends CI_Model {

    private $tabela = 'tb_midias';
    private $primary_key = 'cod_midia';

    function __construct() {
        parent::__construct();
    }
    
    public function lista_midia_by_tipo($tipo = NULL) {
        switch ($tipo):
            case 'Imagem':
                $this->db->where('mid_tipo', 'Imagem');
                $this->db->or_where('mid_tipo', 'Massa');
                break;
            case 'Video':
                $this->db->where('mid_tipo', 'Youtube');
                break;
            case 'Audio':
                $this->db->where('mid_tipo', 'Audio');
                break;
            case 'Arquivo':
                $this->db->where('mid_tipo', 'Arquivo');
                break;
        endswitch;
        $this->db->order_by('mid_data_cad');
        $this->db->where('mid_publicado', '1');
        return $this->db->get($this->tabela);
    }

    /**
     * Este método retorna os ítens de uma galeria especificada
     * pelo link enviado na URL.
     *
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @since 0.1 30/01/2013
     * @param string $link Link amigável da galeria.
     * @return object
     */
    public function get_by_link($id) {
        $this->db->where('mid_link', $id);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método retorna o nome de uma pasta de galerias informando
     * o ID de uma galeria no parãmetro $id
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $id
     * @return string
     */
    public function get_pasta_by_id($id) {
        $this->db->select('mid_pasta');
        $this->db->where('cod_midia', $id);
        $query = $this->db->get('tb_midias')->row();
        return $query->mid_pasta;
    }

    /**
     * Este método retorna uma lista de galerias de mídia que
     * estejam marcadas como publicado ordenando por data de
     * cadastro.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @param int $destaque
     * @return mixed
     */
    public function lista_midia($destaque = FALSE) {
        if ($destaque)
            $this->db->where('mid_destaque', '1');
        $this->db->order_by('mid_data_cad');
        $this->db->where('mid_publicado', '1');
        return $this->db->get($this->tabela);
    }

    /**
     * Este método lista todos os resultados da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function list_all() {
        // Aqui pode-se fazer um filtro e passar os parametros pelo metodo.
        return $this->db->get($this->tabela);
    }

    /**
     * Este método faz a contagem de todos os registros da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function count_all() {
        return $this->db->count_all($this->tabela);
    }

    /**
     * Este método recupera uma consulta com paginação da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function get_paged_list($limit = 10, $offset = 0) {
        $this->db->order_by($this->primary_key, 'asc');
        return $this->db->get($this->tabela, $limit, $offset);
    }

    /**
     * Este método recupera um registro da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function get_by_id($id) {
        $this->db->where($this->primary_key, $id);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método salva um registro na tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function save($dados) {
        $this->db->insert($this->tabela, $dados);
        return $this->db->insert_id();
    }

    /**
     * Este método atualiza um registro na tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function update($id, $dados) {
        $this->db->where($this->primary_key, $id);
        $this->db->update($this->tabela, $dados);
        return $this->db->affected_rows();
    }

    /**
     * Este método exclui um registro da tabela tb_midias.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function delete($id) {
        $this->db->where($this->primary_key, $id);
        $this->db->delete($this->tabela);
        return $this->db->affected_rows();
    }

}

/* Sem fechamento para evitar erros de cabecalho. */
