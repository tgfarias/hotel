<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o gerenciamento da tabela tb_conteudo 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */
class conteudo_model extends CI_Model {

    private $tabela = 'tb_conteudo';
    private $primary_key = 'cod_conteudo';

    function __construct() {
        parent::__construct();
    }
    
    /**
     * Este método efetua uma busca de string no título de um conteúdo.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param string $termo
     * @return object 
     */
    public function get_pesquisa($termo){
        $this->db->like('cnt_titulo', $termo);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método efetua uma consulta na tabela de conteúdos usando a 
     * coluna cnt_link como parametro de busca.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param string $link - Link do conteúdo armazenado na coluna cnt_link
     * @return mixed 
     */
    public function get_by_link($link) {
        $this->db->where('cnt_link', $link);
        $this->db->where('cnt_publicado', '1');
        return $this->db->get($this->tabela);
    }

    /**
     * Este método retorna uma lista de conteúdos aplicando filtros
     * básicos que são passados como parâmetros, o resultado pode ser
     * uma lista ou um único item devendo ser recuperado usando os 
     * comandos result() ou row()
     *
     * Alterações:
     * -----------
     *
     * 23/12/2012 - Retirada do parametro $secao
     * 
     * @author Eliel de Paula <elieldepaula@gmail.com>
     * @access public
     * @param type $tipo
     * @param type $categoria
     * @param type $inicio
     * @param type $fim
     * @return type
     */
    public function get_lista_conteudo($tipo = 'Artigo', $categoria = NULL, $inicio = NULL, $fim = NULL) {
        $this->db->where('cnt_tipo', $tipo);
        $this->db->order_by('cnt_data_cad', 'desc');
        
        if ($categoria)
            $this->db->where('cod_categoria', $categoria);
        if ($inicio)
            $this->db->limit($inicio, $fim);
        
        return $this->db->get($this->tabela);
    }

    /**
     * Este método adiciona +1 ao total de visualizações de um determinado
     * conteúdo que será indicado no parametro ID que se refere à coluna
     * cod_conteudo da tabela de conteudo.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $id
     * @return mixed 
     */
    public function add_view($id) {
        return $this->db->query('UPDATE tb_conteudo SET cnt_views = cnt_views + 1 WHERE cod_conteudo = "' . $id . '"');
    }

    /**
     * Este método lista todos os resultados da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function list_all() {
        // Aqui pode-se fazer um filtro e passar os parametros pelo metodo.
        return $this->db->get($this->tabela);
    }

    /**
     * Este método faz a contagem de todos os registros da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function count_all($cod_categoria = NULL) {
        if($cod_categoria)$this->db->where('cod_categoria',$cod_categoria);
        return $this->db->count_all_results($this->tabela);
    }

    /**
     * Este método recupera uma consulta com paginação da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function get_paged_list($limit = 10, $offset = 0, $cod_categoria = NULL) {
        if($cod_categoria)$this->db->where('cod_categoria',$cod_categoria);
        $this->db->order_by($this->primary_key, 'asc');
        return $this->db->get($this->tabela, $limit, $offset);
    }

    /**
     * Este método recupera um registro da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function get_by_id($id) {
        $this->db->where($this->primary_key, $id);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método salva um registro na tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function save($dados) {
        $this->db->insert($this->tabela, $dados);
        return $this->db->insert_id();
    }

    /**
     * Este método atualiza um registro na tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function update($id, $dados) {
        $this->db->where($this->primary_key, $id);
        $this->db->update($this->tabela, $dados);
        return $this->db->affected_rows();
    }

    /**
     * Este método exclui um registro da tabela tb_conteudo.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function delete($id) {
        $this->db->where($this->primary_key, $id);
        $this->db->delete($this->tabela);
        return $this->db->affected_rows();
    }
    
    /**
     * Este método retorna o relacionamento da tabela tb_categorias.
     * 
     * @access public 
     * @author Gerado automaticamente <contato@elieldepaula.com.br> 
     * @return boolean 
     */
    public function relacionamento($chave = '', $valor = ''){
        if($valor)$this->db->where($chave, $valor);
        return $this->db->get($this->tabela);
    }

}

/* Sem fechamento para evitar erros de cabecalho. */