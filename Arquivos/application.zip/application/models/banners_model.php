<?php

if (!defined('BASEPATH'))
    exit('Acesso direto ao script negado.');

/**
 * Esta classe foi gerada automaticamente pelo sistema de geração 
 * de CMS para Codeigniter desenvolvido por Eliel de Paula. 
 * 
 * Esta classe fornece os atributos e métodos necessários para 
 * o gerenciamento da tabela tb_banners 
 * 
 * @author Eliel de Paula - <elieldepaula@gmail.com> 
 * @since 26/07/2012 
 * @version 0.0.1 
 * 
 */

class banners_model extends CI_Model {

    private $tabela = 'tb_banners';
    private $primary_key = 'cod_banner';

    function __construct() {
        parent::__construct();
    }

    /**
     * Este método retorna os dados de um registro de banner com base
     * na posição informada no parametro.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param string $posicao
     * @return mixed 
     */
    public function get_by_posicao($posicao) {
        $this->db->where('ban_posicao', $posicao);
        $this->db->where('ban_ativo', '1');
        return $this->db->get($this->tabela);
    }

    /**
     * Este método adiciona +1 ao contador de cliques para estatísticas
     * de rendimento dos banners.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $cod_banner
     * @return boolean 
     */
    public function add_click($cod_banner) {
        return $this->db->query('UPDATE tb_banners SET ban_click = ban_click + 1 WHERE cod_banner = "' . $cod_banner . '"');
    }

    /**
     * Este método adiciona +1 ao contador de visualizações para estatísticas
     * de rendimento dos banners.
     * 
     * @access public
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @param int $cod_banner
     * @return boolean 
     */
    public function add_view($cod_banner) {
        return $this->db->query('UPDATE tb_banners SET ban_views = ban_views + 1 WHERE cod_banner = "' . $cod_banner . '"');
    }

    /**
     * Este método lista todos os resultados da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function list_all() {
        // Aqui pode-se fazer um filtro e passar os parametros pelo metodo.
        return $this->db->get($this->tabela);
    }

    /**
     * Este método faz a contagem de todos os registros da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function count_all() {
        return $this->db->count_all($this->tabela);
    }

    /**
     * Este método recupera uma consulta com paginação da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function get_paged_list($limit = 10, $offset = 0) {
        $this->db->order_by($this->primary_key, 'asc');
        return $this->db->get($this->tabela, $limit, $offset);
    }

    /**
     * Este método recupera um registro da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    public function get_by_id($id) {
        $this->db->where($this->primary_key, $id);
        return $this->db->get($this->tabela);
    }

    /**
     * Este método salva um registro na tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function save($dados) {
        $this->db->insert($this->tabela, $dados);
        return $this->db->insert_id();
    }

    /**
     * Este método atualiza um registro na tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function update($id, $dados) {
        $this->db->where($this->primary_key, $id);
        $this->db->update($this->tabela, $dados);
        return $this->db->affected_rows();
    }

    /**
     * Este método exclui um registro da tabela tb_banners.
     * 
     * @access public 
     * @author Eliel de Paula <elieldepaula@gmail.com> 
     * @return boolean 
     */
    function delete($id) {
        $this->db->where($this->primary_key, $id);
        $this->db->delete($this->tabela);
        return $this->db->affected_rows();
    }

}

/* Sem fechamento para evitar erros de cabecalho. */

